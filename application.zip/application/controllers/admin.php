<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Admin extends CI_Controller {
    /*     * * 
     * An Controller having functions to manage admin user login,add edit, forgot password, profile and activating user account
     * * */

    public function __construct() {
        parent::__construct();
        $this->load->model('common_model');
    }

    /* function for admin login  */

    public function index() {
        if ($this->input->post('user_name') != '') {
            $arr_admin_details_with_username = $this->common_model->getRecords("mst_users", "*", array("user_name" => $this->input->post('user_name')));
            if (count($arr_admin_details_with_username) > 0) {

                /* admin details with user_name and user_password : */
                $arr_admin_details_username_password = $this->common_model->getRecords("mst_users", "*", array("user_name" => $this->input->post('user_name'), "user_password" => base64_encode($this->input->post('user_password')), "user_type" => '2'), '', '', 0);

                if (count($arr_admin_details_username_password) > 0) {
                    //echo $arr_admin_details_username_password[0]['user_status'];
                    if ($arr_admin_details_username_password[0]['user_status'] == 1) {

                        /* addding user data into the session */
                        $user_account['user_id'] = $arr_admin_details_username_password[0]['user_id'];
                        $user_account['user_name'] = stripslashes($arr_admin_details_username_password[0]['user_name']);
                        $user_account['user_email'] = $arr_admin_details_username_password[0]['user_email'];
                        $user_account['user_type'] = $arr_admin_details_username_password[0]['user_type'];
                        $user_account['role_id'] = $arr_admin_details_username_password[0]['role_id'];

                        $user_account['first_name'] = stripslashes($arr_admin_details_username_password[0]['first_name']);
                        print_r($user_account);
                        $user_account['location_id'] = $arr_admin_details_username_password[0]['location_id'];
                        $user_account['last_name'] = stripslashes($arr_admin_details_username_password[0]['last_name']);
                        $arr_privileges = $this->common_model->getRecords('trans_role_privileges', 'privilege_id', array("role_id" => $arr_admin_details_username_password[0]['role_id']));
                        /* serializing the user privilegse and setting into the session. While ussing user privileges use unserialize this session to get user privileges */
                        if (count($arr_privileges) > 0) {
                            foreach ($arr_privileges as $privilege) {
                                $user_privileges[] = $privilege['privilege_id'];
                            }
                        } else {
                            $user_privileges = array();
                        }
                        $user_account['user_privileges'] = ($user_privileges);
                        $this->session->set_userdata('user_account', $user_account);
                        $this->session->set_userdata('admin_user_name', $user_account['user_name']);
                        $user_account = $this->session->userdata('user_account');
                        redirect("backend/home");
                    } else if ($arr_admin_details_username_password[0]['user_status'] == 2) {
                        /* user account is blocked by admin */
                        /* getting all blocked user from file */
                        $absolute_path = $this->common_model->absolutePath();
                        if (file_exists($absolute_path . "media/front/user-status/blocked-user")) {
                            $blocked_user = $this->common_model->read_file($absolute_path . "media/front/user-status/blocked-user");
                            if (in_array($arr_admin_details_username_password[0]['user_id'], $blocked_user)) {
                                /* removing the user from the bloked file list */
                                $key = array_search($arr_admin_details_username_password[0]['user_id'], $blocked_user);
                                if ($key !== false) {
                                    unset($blocked_user[$key]);
                                }
                                $this->common_model->write_file($absolute_path . "media/front/user-status/blocked-user", $blocked_user);
                            }
                        }

                        $msg = '<div class="alert alert-block"><strong>Sorry!</strong> Your account has been blocked by Administrator.</div>';
                        $this->session->set_userdata('msg', $msg);
                        redirect("backend/login");
                    } else if ($arr_admin_details_username_password[0]['user_status'] == 0) {
                        /* user account is in inactive status  */

                        $msg = '<div class="alert alert-block">Please activate your account through link provided on your email address.</div>';
                        $this->session->set_userdata('msg', $msg);
                        redirect("backend/login");
                    }
                 }
        //user login
                 else if (count($arr_admin_details_with_username) > 0) {
                    $arr_admin_details_username_password = $this->common_model->getRecords("mst_users", "*", array("user_name" => $this->input->post('user_name'), "user_password" => base64_encode($this->input->post('user_password')), "user_type" => '1'), '', '', 0);
                    if (count($arr_admin_details_username_password) > 0) {
                    //echo $arr_admin_details_username_password[0]['user_status'];
                    if ($arr_admin_details_username_password[0]['user_status'] == 1) {

                        /* addding user data into the session */
                        $user_account['user_id'] = $arr_admin_details_username_password[0]['user_id'];
                        $user_account['user_name'] = stripslashes($arr_admin_details_username_password[0]['user_name']);
                        $user_account['user_email'] = $arr_admin_details_username_password[0]['user_email'];
                        $user_account['user_type'] = $arr_admin_details_username_password[0]['user_type'];
                        $user_account['role_id'] = $arr_admin_details_username_password[0]['role_id'];
                        $user_account['location_id'] = $arr_admin_details_username_password[0]['location_id'];
                        $user_account['first_name'] = stripslashes($arr_admin_details_username_password[0]['first_name']);
                        print_r($user_account);

                        $user_account['last_name'] = stripslashes($arr_admin_details_username_password[0]['last_name']);
                        $arr_privileges = $this->common_model->getRecords('trans_role_privileges', 'privilege_id', array("role_id" => $arr_admin_details_username_password[0]['role_id']));
                        /* serializing the user privilegse and setting into the session. While ussing user privileges use unserialize this session to get user privileges */
                        if (count($arr_privileges) > 0) {
                            foreach ($arr_privileges as $privilege) {
                                $user_privileges[] = $privilege['privilege_id'];
                            }
                        } else {
                            $user_privileges = array();
                        }
                        $user_account['user_privileges'] = ($user_privileges);
                        $this->session->set_userdata('user_account', $user_account);
                        $this->session->set_userdata('admin_user_name', $user_account['user_name']);
                        $user_account = $this->session->userdata('user_account');

                        redirect("backend/home");
                    } else if ($arr_admin_details_username_password[0]['user_status'] == 2) {
                        /* user account is blocked by admin */
                        /* getting all blocked user from file */
                        $absolute_path = $this->common_model->absolutePath();
                        if (file_exists($absolute_path . "media/front/user-status/blocked-user")) {
                            $blocked_user = $this->common_model->read_file($absolute_path . "media/front/user-status/blocked-user");
                            if (in_array($arr_admin_details_username_password[0]['user_id'], $blocked_user)) {
                                /* removing the user from the bloked file list */
                                $key = array_search($arr_admin_details_username_password[0]['user_id'], $blocked_user);
                                if ($key !== false) {
                                    unset($blocked_user[$key]);
                                }
                                $this->common_model->write_file($absolute_path . "media/front/user-status/blocked-user", $blocked_user);
                            }
                        }

                        $msg = '<div class="alert alert-block"><strong>Sorry!</strong> Your account has been blocked by Administrator.</div>';
                        $this->session->set_userdata('msg', $msg);
                        redirect("backend/login");
                    }else if ($arr_admin_details_username_password[0]['user_status'] == 0) {
                        /* user account is in inactive status  */

                        $msg = '<div class="alert alert-block">Please activate your account through link provided on your email address.</div>';
                        $this->session->set_userdata('msg', $msg);
                        redirect("backend/login");
                    }

                     
                 }
             }

                  else {
                    /* alerting message for invalid password */
                    $msg = '<div class="alert alert-error"><strong>Sorry!</strong> Invalid password.</div>';
                    $this->session->set_userdata('msg', $msg);
                    redirect("backend/login");
                }
            } 
//userr
            else {
                /* alerting message for invalid usename */
                $msg = '<div class="alert alert-error"><strong>Sorry!</strong> Invalid username.</div>';
                $this->session->set_userdata('msg', $msg);
                redirect("backend/login");
            }
        }

        $data['global'] = $this->common_model->getGlobalSettings();
        $data['title'] = "Login To Admin Panel";
        $this->load->view('backend/log-in/login', $data);
    }


    public function change_language_for_functionality() {
        if ($this->input->post('type') == 'Single') {
            $this->config->set_item('is_multi_language', 'No');
            echo "true";
        } else {
            $this->config->set_item('is_multi_language', 'Yes');
            echo "true";
        }
    }

    /* function for admin dashbaord */
    public function user_id(){
        $data = $this->common_model->getRecords('mst_users','',array('user_id'=>$this->input->post('value1'),'user_password'=>base64_encode($this->input->post('value'))));
            echo json_encode($data);
        
    }
    public function home() {

        /* checking admin is logged in or not */
        if (!$this->common_model->isLoggedIn()) {
            redirect(base_url() . "backend/login");
        }

        $user_account = $this->session->userdata('user_account');
        if (empty($user_account)) {
            redirect(base_url() . "backend/login");
        }
        $data = $this->common_model->commonFunction();

        $data['title'] = "Dashboard";
        $data['current_page_path'] = '<div class="breadcrumbDivider"></div><a class="current">Dashboard</a>';
        /* getting total count of admin */
        $data['arr_admin_details_with_username'] = $this->common_model->getRecords('mst_users', '', array('user_type' => 2));
        $data['arr_user_details_with_username'] = $this->common_model->getWebsiteUsersCount();
        $data['totalCount'] = count($data['arr_admin_details_with_username']);
        /*$data['arr_volunteer_details'] = $this->common_model->getRecords('volunteer_details', '*');
        
        $data['arr_ngo_details_with_username'] = $this->common_model->getRecords('ngo_details', '*');

        $data['arr_enable_ngo_user'] = $this->common_model->getRecords('ngo_details', '', array('admin_status' => '1'));

        $data['arr_desable_ngo_user'] = $this->common_model->getRecords('ngo_details', '', array('admin_status' => '0'));

        $data['arr_enable_volunteer_user'] = $this->common_model->getRecords('volunteer_details', '', array('admin_status' => '1'));

        $data['arr_desable_volunteer_user'] = $this->common_model->getRecords('volunteer_details', '', array('admin_status' => '0'));

        $data['totalCount'] = count($data['arr_admin_details_with_username']);
        $data['total_count_users'] = count($data['arr_user_details_with_username']);
        $data['total_count_volunteer']= count($data['arr_volunteer_details']);
        $data['total_count_ngo']= count($data['arr_ngo_details_with_username']);

        $data['total_count_enable_ngo']= count($data['arr_enable_ngo_user']);

        $data['total_count_desable_ngo']= count($data['arr_desable_ngo_user']);

        $data['total_count_enable_volunteer']= count($data['arr_enable_volunteer_user']);

        $data['total_count_desable_volunteer']= count($data['arr_desable_volunteer_user']);*/
        
        $data['user_list_for_count'] = $this->common_model->getRecords('user_details', '*');
        $data['subadmin_master'] = $this->common_model->getRecords('mst_users','',array('role_id'=> 2 ));
        $data['login'] = $this->common_model->getRecords('login');
        $data['entry'] = $this->common_model->getRecords('order_entryhd');
        $data['entrydt']= $this->common_model->getRecords('order_entry');
        $data1 = $this->session->userdata('user_account');
        $arr1 = array('status'=>'Received','login.subad_id'=>$data1['user_id']);
        $data['order_entryhd'] = $this->common_model->order_product_subadmin($arr1);
         $arr1 = array('status'=>'Processing','login.subad_id'=>$data1['user_id']);
        $data['accept'] = $this->common_model->order_product_subadmin($arr1);
        
         $arr1 = array('status'=>'Shipped','login.subad_id'=>$data1['user_id']);
        $data['Shipped'] = $this->common_model->order_product_subadmin($arr1);
         $arr1 = array('status'=>'Delivered','login.subad_id'=>$data1['user_id']);
        $data['Delivered'] = $this->common_model->order_product_subadmin($arr1);
         $arr1 = array('status'=>'Cancelled','login.subad_id'=>$data1['user_id']);
        $data['Cancelled'] = $this->common_model->order_product_subadmin($arr1);
        $this->session->set_userdata('order_status','Received Order');
        
        //$data['product_list_for_count'] = $this->common_model->getRecords('product_details', '*');
        //$data['stock_list_for_count'] = $this->common_model->getRecords('stock_temp', '*');

        $this->load->view('backend/index', $data);
    }

    /* function for logour user from admin panel.    */

    public function logout() {
        /* unseting the user session data. */
        $this->session->unset_userdata("user_account");
        redirect(base_url() . "backend/login");
    }

    /* function for admin forgot password functionality */

    public function forgotPassword() {
        if (count($_POST) > 0) {
            if ($this->input->post('user_email') != '') {
                /* getting admin details if exist from email */
                $arr_admin_detail = $this->common_model->getRecords("mst_users", '', array("user_email" => $this->input->post('user_email')));
                $arr_admin_detail = end($arr_admin_detail);
                if (count($arr_admin_detail) > 0) {
                    $data['global'] = $this->common_model->getGlobalSettings();
                    /* sending admin credentail on admin account mail on user email */
                    $lang_id = 17;
                    $admin_login_link = '<a href="' . base_url() . 'backend/login" target="_new">Log in to ' . stripslashes($data['global']['site_title']) . ' administration</a>';
                    /* setting reserved_words for email content */
                    $macros_array_detail = array();
                    $macros_array_detail = $this->common_model->getRecords('mst_email_template_macros', 'macros,value', $condition_to_pass = '', $order_by = '', $limit = '', $debug = 0);
                    $macros_array = array();
                    foreach ($macros_array_detail as $row) {
                        $macros_array[$row['macros']] = $row['value'];
                    }
                    $reserved_words = array();

                    $reserved_arr = array(
                        "||SITE_TITLE||" => stripslashes($data['global']['site_title']),
                        "||SITE_PATH||" => base_url(),
                        "||USER_NAME||" => $arr_admin_detail['user_name'],
                        "||ADMIN_NAME||" => $arr_admin_detail['first_name'] . ' ' . $arr_admin_detail['last_name'],
                        "||ADMIN_EMAIL||" => $arr_admin_detail['user_email'],
                        "||PASSWORD||" => base64_decode($arr_admin_detail['user_password']),
                        "||ADMIN_LOGIN_LINK||" => $admin_login_link
                    );
                    $reserved_words = array_replace_recursive($macros_array, $reserved_arr);
                    /* getting mail subect and mail message using email template title and lang_id and reserved works */
                    $email_content = $this->common_model->getEmailTemplateInfo('admin-forgot-password', 17, $reserved_words);
                    /* sending admin user mail for forgot password */
                    /* 1.recipient array. 2.From array containing email and name, 3.Mail subject 4.Mail Body */
                    $mail = $this->common_model->sendEmail(array($arr_admin_detail['user_email']), array("email" => $data['global']['site_email'], "name" => stripslashes($data['global']['site_title'])), $email_content['subject'], $email_content['content']);
                    if ($mail) {
                        $this->session->set_userdata('msg', '<div class="alert alert-success">Your login details has been sent successfully.</div>');
                        redirect(base_url() . "backend/login");
                        exit;
                    } else {
                        $this->session->set_userdata('msg', '<div class="alert alert-error">Error occurred during sending mail, please try latter.</div>');
                        redirect(base_url() . "backend/forgot-password");
                        exit;
                    }
                } else {
                    $this->session->set_userdata('msg', '<div class="alert alert-error">Your email is not registered with us.</div>');
                    redirect(base_url() . "backend/forgot-password");
                    exit;
                }
            }
        }
        $data['title'] = "Forgot Password";
        $this->load->view('backend/log-in/forgot-password', $data);
    }

    public function checkForgotPasswordEmail() {
        /* checking email is exist or not for forgot password email entry */
        $arr_admin_detail = $this->common_model->getRecords('mst_users', "", array("user_email" => $this->input->post('user_email')));
        if (count($arr_admin_detail) == 0) {
            echo "false";
        } else {
            echo "true";
        }
    }

    /* function to list all the roles */

    public function listAdmin() {
        /* checking admin is logged in or not */
        if (!$this->common_model->isLoggedIn()) {
            redirect(base_url() . "backend/login");
        }
        /* Getting Common data */
        $data = $this->common_model->commonFunction();
        /* checking user has privilige for the Manage Admin */
        if ($data['user_account']['role_id'] != 1) {
            /* an admin which is not super admin not privileges to access Manage Role */
            /* setting session for displaying notiication message. */
            $this->session->set_userdata("msg", "<span class='error'>You doesn't have priviliges to  manage admin!</span>");
            redirect(base_url() . "backend/home");
        }
        if (count($_POST) > 0) {
            if (isset($_POST['btn_delete_all'])) {
                /* getting all ides selected */
                $arr_user_ids = $this->input->post('checkbox');
                if (count($arr_user_ids) > 0) {
                    foreach ($arr_user_ids as $user_id) {
                        /* getting admin details */
                        $arr_admin_detail = $this->common_model->getRecords("mst_users", "", array("user_id" => intval($user_id)));
                        if (count($arr_admin_detail) > 0) {
                            /* setting reserved_words for email content */
                            $lang_id = 17;
                            $macros_array_detail = array();
                            $macros_array_detail = $this->common_model->getRecords('mst_email_template_macros', 'macros,value', $condition_to_pass = '', $order_by = '', $limit = '', $debug = 0);
                            $macros_array = array();
                            foreach ($macros_array_detail as $row) {
                                $macros_array[$row['macros']] = $row['value'];
                            }
                            $reserved_words = array();

                            $reserved_arr = array("||SITE_TITLE||" => stripslashes($data['global']['site_title']),
                                "||SITE_PATH||" => base_url(),
                                "||ADMIN_NAME||" => $arr_admin_detail[0]['first_name'] . ' ' . $arr_admin_detail[0]['last_name']
                            );

                            $reserved_words = array_replace_recursive($macros_array, $reserved_arr);
                            $template_title = 'admin-deleted';
                            /* getting mail subject and mail message using email template title and lang_id and reserved works */
                            $email_content = $this->common_model->getEmailTemplateInfo('admin-deleted', 17, $reserved_words);
                            /* sending admin user mail for account deletion. */
                            /* 1.recipient array. 2.From array containing email and name, 3.Mail subject 4.Mail Body */
                            $mail = $this->common_model->sendEmail(array($arr_admin_detail[0]['user_email']), array("email" => $data['global']['site_email'], "name" => stripslashes($data['global']['site_title'])), $email_content['subject'], $email_content['content']);
                            /* Addmin the user in bloked list into file */
                            $this->load->model('admin_model');
                            $this->admin_model->updateDeletedUserFile($this->common_model->absolutePath(), intval($user_id));
                        }
                    }
                    //if (isset($_POST) && (isset($_POST['user_id'])&& $_POST['user_id']) > 0)
                    if (count($arr_user_ids) > 0) {
                        /* deleting the admin selected */
                        $this->common_model->deleteRows($arr_user_ids, "mst_users", "user_id");
                    }
                    $this->session->set_userdata("msg", "<span class='success'>Admin deleted successfully!</span>");
                }
            }
        }

        /* using the admin model */
        $this->load->model('admin_model');
        $data['title'] = "Manage Admin";
        $data['arr_admin_list'] = $this->admin_model->getAdminDetails('');
        $this->load->view('backend/admin/list', $data);
    }

    public function changeStatus() {
        if ($this->input->post('user_id') != "") {
            /* updating the user status. */
            $arr_to_update = array("user_status" => $this->input->post('user_status'));
            /* condition to update record   for the admin status */
            $condition_array = array('user_id' => intval($this->input->post('user_id')));
            /* updating the global setttings parameter value into database */
            $this->common_model->updateRow('mst_users', $arr_to_update, $condition_array);
            /* Addmin the user in bloked list into file */
            $this->load->model('admin_model');
            $this->admin_model->updateBlockedUserFile($this->common_model->absolutePath(), $this->input->post('user_status'), intval($this->input->post('user_id')));
            echo json_encode(array("error" => "0", "error_message" => "Your Account has been deleted successfully"));
        } else {
            /* if something going wrong providing error message.  */
            echo json_encode(array("error" => "1", "error_message" => "Sorry, your request can not be fulfilled this time. Please try again later"));
        }
    }

    /* function to check existancs of user name */

    public function checkAdminUsername() {
        if (isset($_POST['type'])) {
            /* checking admin user name already exist or not for edit Admin */
            if (strtolower($this->input->post('user_name')) == strtolower($this->input->post('old_username'))) {
                echo "true";
            } else {
                $arr_admin_detail = $this->common_model->getRecords('mst_users', 'user_name', array("user_name" => ($this->input->post('user_name'))));
                if (count($arr_admin_detail) == 0) {
                    echo "true";
                } else {
                    echo "false";
                }
            }
        } else {
            /* checking admin user name already exist or not for add admin  */
            $arr_admin_detail = $this->common_model->getRecords('mst_users', 'user_name', array("user_name" => ($this->input->post('user_name'))));
            if (count($arr_admin_detail) == 0) {
                echo "true";
            } else {
                echo "false";
            }
        }
    }

    /* function to check existancs of user email */

    public function checkAdminEmail() {
        if (isset($_POST['type'])) {
            /* checking admin email already exist or not for edit Admin */
            if (strtolower($this->input->post('user_email')) == strtolower($this->input->post('old_email'))) {
                echo "true";
            } else {
                $arr_admin_detail = $this->common_model->getRecords('mst_users', 'user_email', array("user_email" => mysql_real_escape_string($this->input->post('user_email'))));
                if (count($arr_admin_detail) == 0) {
                    echo "true";
                } else {
                    echo "false";
                }
            }
        } else {
            /* checking admin email already exist or not for add admin */
            $arr_admin_detail = $this->common_model->getRecords('mst_users', 'user_email', array("user_email" => mysql_real_escape_string($this->input->post('user_email'))));
            if (count($arr_admin_detail) == 0) {
                echo "true";
            } else {
                echo "false";
            }
        }
    }

    /* function to add new admin user from backend  */

    public function addAdmin() {
        /* checking admin is logged in or not */
        if (!$this->common_model->isLoggedIn()) {
            redirect(base_url() . "backend/login");
        }

        /* getting common data */
        $data = $this->common_model->commonFunction();

        /* checking user has privilige for the Manage Admin */
        if ($data['user_account']['role_id'] != 1) {
            /* an admin which is not super admin not privileges to access Manage Admin */
            /* setting session for displaying notiication message. */
            $this->session->set_userdata("msg", "<span class='error'>You doesn't have priviliges to  manage admin!</span>");
            redirect(base_url() . "backend/home");
        }
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<p class="validationError">', '</p>');
        $this->form_validation->set_rules('user_name', 'admin username', 'required');
        $this->form_validation->set_rules('first_name', 'admin first name', 'required');
        $this->form_validation->set_rules('last_name', 'admin last name', 'required');
        $this->form_validation->set_rules('user_email', 'admin email', 'required|valid_email');
        $this->form_validation->set_rules('user_password', 'admin password', 'required');
        $this->form_validation->set_rules('role_id', 'admin role', 'required');
        if (count($_POST) > 0) {

            if ($this->form_validation->run() == true && $this->input->post('user_name') != "") {

                $activation_code = time();
                /* user record to add */
                $arr_to_insert = array(
                    "user_name" => mysql_real_escape_string($this->input->post('user_name')),
                    "first_name" => mysql_real_escape_string($this->input->post('first_name')),
                    "last_name" => mysql_real_escape_string($this->input->post('last_name')),
                    "user_email" => mysql_real_escape_string($this->input->post('user_email')),
                    "user_password" => base64_encode($this->input->post('user_password')),
                    'gender' => $this->input->post('gender'),
                    'user_type' => 2,
                    'user_status' => 0,
                    'activation_code' => $activation_code,
                    'email_verified' => 0,
                    'role_id' => $this->input->post('role_id'),
                    'register_date' => date("Y-m-d H:i:s")
                );
                /* inserting admin details into the dabase */
                $last_insert_id = $this->common_model->insertRow($arr_to_insert, "mst_users");
                /* Activation link  */
                $activation_link = '<a href="' . base_url() . 'backend/admin/account-activate/' . $activation_code . '">Activate Account</a>';
                /* setting reserved_words for email content */
                $macros_array_detail = array();
                $macros_array_detail = $this->common_model->getRecords('mst_email_template_macros', 'macros,value', $condition_to_pass = '', $order_by = '', $limit = '', $debug = 0);
                $macros_array = array();
                foreach ($macros_array_detail as $row) {
                    $macros_array[$row['macros']] = $row['value'];
                }
                $reserved_words = array();

                $reserved_arr = array(
                    "||SITE_TITLE||" => stripslashes($data['global']['site_title']),
                    "||SITE_PATH||" => base_url(),
                    "||USER_NAME||" => $this->input->post('user_name'),
                    "||ADMIN_NAME||" => $this->input->post('first_name') . ' ' . $this->input->post('last_name'),
                    "||ADMIN_EMAIL||" => $this->input->post('user_email'),
                    "||PASSWORD||" => $this->input->post('user_password'),
                    "||ADMIN_ACTIVATION_LINK||" => $activation_link
                );
                $reserved_words = array_replace_recursive($macros_array, $reserved_arr);
                /* getting mail subect and mail message using email template title and lang_id and reserved works */
                $email_content = $this->common_model->getEmailTemplateInfo('admin-added', 17, $reserved_words);

                /* sending admin added mail to added admin mail id. */
                /* 1.recipient array. 2.From array containing email and name, 3.Mail subject 4.Mail Body */
                $mail = $this->common_model->sendEmail(array($this->input->post('user_email')), array("email" => $data['global']['site_email'], "name" => stripslashes($data['global']['site_title'])), $email_content['subject'], $email_content['content']);
                $this->session->set_userdata("msg", "<span class='success'>Admin added successfully and verification email sent to email address.</span>");
                redirect(base_url() . "backend/admin/list");
            }
        }
        $arr_privileges = array();
        /* getting all privileges */
        $data['arr_privileges'] = $this->common_model->getRecords('mst_privileges');
        $data['title'] = "Add Admin User";
        $data['arr_roles'] = $this->common_model->getRecords("mst_role");
        $this->load->view('backend/admin/add', $data);
    }

    /* function to activate user account */

    public function activateAccount($activation_code) {
        $fields_to_pass = array('user_id', 'first_name', 'last_name', 'user_name', 'user_email', 'user_type', 'email_verified', 'user_status');
        /* get user details to verify the email address */
        $arr_login_data = $this->common_model->getRecords("mst_users", $fields_to_pass, array("activation_code" => $activation_code));
        if (count($arr_login_data)) {
            /* if email already verified */
            if ($arr_login_data[0]['email_verified'] == 1) {
                $this->session->set_userdata('msg', '<div class="alert alert-success">Your have already activated your account. Please login.</div>');
            } else {
                /* if email not verified. */
                $update_data = array('email_verified' => '1', 'user_status' => '1');
                $this->common_model->updateRow("mst_users", $update_data, array("activation_code" => $activation_code));
                $this->session->set_userdata('msg', '<div class="alert alert-success"><strong>Congratulation!</strong> Your account has been activated successfully. Please login.</div>');
            }
        } else {
            /* if any error invalid activation link found account */
            $_SESSION['msg'] = '<div class="alert alert-error">Invalid activation code.</div>';
        }
        redirect(base_url() . "backend/login");
    }

    public function editAdmin($edit_id = '') {
        /* checking admin is logged in or not */
        if (!$this->common_model->isLoggedIn()) {
            redirect(base_url() . "backend/login");
        }
        $data = $this->common_model->commonFunction();

        /* checking user has privilige for the Manage Admin */
        if ($data['user_account']['role_id'] != 1) {
            /* an admin which is not super admin not privileges to access Manage Admin */
            /* setting session for displaying notiication message. */
            $this->session->set_userdata("msg", "<span class='error'>You doesn't have priviliges to  manage admin!</span>");
            redirect(base_url() . "backend/home");
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<p class="validationError">', '</p>');
        $this->form_validation->set_rules('user_name', 'admin username', 'required');
        $this->form_validation->set_rules('first_name', 'admin first name', 'required');
        $this->form_validation->set_rules('last_name', 'admin last name', 'required');
        $this->form_validation->set_rules('user_email', 'admin email', 'required|valid_email');

        if ($this->form_validation->run() == true && $this->input->post('user_name') != "") {

            if ($this->input->post('edit_id') != "") {
                $arr_admin_detail = $this->common_model->getRecords("mst_users", "", array("user_id" => intval($this->input->post('edit_id'))));
                /* single row fix */
                $arr_admin_detail = end($arr_admin_detail);
                /* setting variable to update or add admin record. */
                if ($this->input->post('user_email') == $this->input->post('old_email')) {
                    if ($this->input->post('user_status') != "") {
                        $status = $this->input->post('user_status');
                        $email_verified = '1';
                    } else {
                        $status = '0';
                        $email_verified = '0';
                    }
                    $activation_code = $arr_admin_detail['activation_code'];
                } else {

                    if ($arr_admin_detail['role_id'] != 1) {
                        $status = '0';
                        $email_verified = '0';
                        $activation_code = time();
                    } else {
                        $status = '1';
                        $email_verified = '1';
                        $activation_code = time();
                    }
                }

                /* if status blocked or activated by admin */
                if ($status == '2' || $status == '1') {

                    $this->load->model('admin_model');
                    $this->admin_model->updateBlockedUserFile($this->common_model->absolutePath(), $status, intval($this->input->post('edit_id')));
                }
                if ($this->input->post('change_password') == 'on') {
                    $user_password = $_POST['user_password'];

                    /* if password need to change */
                    $arr_to_update = array(
                        "user_name" => mysql_real_escape_string($this->input->post('user_name')),
                        "first_name" => mysql_real_escape_string($this->input->post('first_name')),
                        "last_name" => mysql_real_escape_string($this->input->post('last_name')),
                        "user_email" => mysql_real_escape_string($this->input->post('user_email')),
                        "user_password" => base64_encode($this->input->post('user_password')),
                        "user_status" => $status,
                        'email_verified' => $email_verified,
                        'gender' => $this->input->post('gender'),
                        'activation_code' => $activation_code,
                        'role_id' => $this->input->post('role_id'),
                    );
                } else {
                    $user_password = base64_decode($arr_admin_detail['user_password']);
                    /* if passwording need not need to change */
                    $arr_to_update = array(
                        "user_name" => mysql_real_escape_string($this->input->post('user_name')),
                        "first_name" => mysql_real_escape_string($this->input->post('first_name')),
                        "last_name" => mysql_real_escape_string($this->input->post('last_name')),
                        "user_email" => mysql_real_escape_string($this->input->post('user_email')),
                        "user_status" => $status,
                        'gender' => $this->input->post('gender'),
                        'email_verified' => $email_verified,
                        'activation_code' => $activation_code,
                        'role_id' => $this->input->post('role_id')
                    );
                }
                /* updating the user details */
                $this->common_model->updateRow("mst_users", $arr_to_update, array("user_id" => $this->input->post('edit_id')));

                if ($this->input->post('user_email') == $this->input->post('old_email')) {
                    if ($arr_admin_detail['role_id'] != 1) {
                        /* sending account updating mail to user */
                        $admin_login_link = '<a href="' . base_url() . 'backend/login" target="_new">Log in to ' . base_url() . 'administration</a>';

                        $macros_array_detail = array();
                        $macros_array_detail = $this->common_model->getRecords('mst_email_template_macros', 'macros,value', $condition_to_pass = '', $order_by = '', $limit = '', $debug = 0);
                        $macros_array = array();
                        foreach ($macros_array_detail as $row) {
                            $macros_array[$row['macros']] = $row['value'];
                        }
                        $reserved_words = array();

                        $reserved_arr = array
                            ("||SITE_TITLE||" => stripslashes($data['global']['site_title']),
                            "||SITE_PATH||" => base_url(),
                            "||USER_NAME||" => $this->input->post('user_name'),
                            "||ADMIN_NAME||" => $this->input->post('first_name') . ' ' . $this->input->post('last_name'),
                            "||ADMIN_EMAIL||" => $this->input->post('user_email'),
                            "||PASSWORD||" => $user_password,
                            "||ADMIN_LOGIN_LINK||" => $admin_login_link
                        );
                        $reserved_words = array_replace_recursive($macros_array, $reserved_arr);

                        /* getting mail subect and mail message using email template title and lang_id and reserved works */
                        $email_content = $this->common_model->getEmailTemplateInfo('admin-updated', 17, $reserved_words);
                        /* sending the mail to deleting user */
                        /* 1.recipient array. 2.From array containing email and name, 3.Mail subject 4.Mail Body */
                        $mail = $this->common_model->sendEmail(array($this->input->post('user_email')), array("email" => $data['global']['site_email'], "name" => stripslashes($data['global']['site_title'])), $email_content['subject'], $email_content['content']);
                    }
                } else {

                    /* sending account verification link mail to user */
                    $lang_id = 17;
                    $activation_link = '<a href="' . base_url() . 'backend/admin/account-activate/' . $activation_code . '">Activate Account</a>';

                    $macros_array_detail = array();
                    $macros_array_detail = $this->common_model->getRecords('mst_email_template_macros', 'macros,value', $condition_to_pass = '', $order_by = '', $limit = '', $debug = 0);
                    $macros_array = array();
                    foreach ($macros_array_detail as $row) {
                        $macros_array[$row['macros']] = $row['value'];
                    }
                    $reserved_words = array();
                    $reserved_arr = array
                        ("||SITE_TITLE||" => stripslashes($data['global']['site_title']),
                        "||SITE_PATH||" => base_url(),
                        "||USER_NAME||" => $this->input->post('user_name'),
                        "||ADMIN_NAME||" => $this->input->post('first_name') . ' ' . $this->input->post('last_name'),
                        "||ADMIN_EMAIL||" => $this->input->post('user_email'),
                        "||PASSWORD||" => $user_password,
                        "||ADMIN_ACTIVATION_LINK||" => $activation_link
                    );
                    $reserved_words = array_replace_recursive($macros_array, $reserved_arr);
                    /* getting mail subect and mail message using email template title and lang_id and reserved works */
                    $email_content = $this->common_model->getEmailTemplateInfo('admin-email-updated', 17, $reserved_words);
                    /* sending the mail to deleting user */
                    /* 1.recipient array. 2.From array containing email and name, 3.Mail subject 4.Mail Body */
                    $mail = $this->common_model->sendEmail(array($this->input->post('user_email')), array("email" => $data['global']['site_email'], "name" => stripslashes($data['global']['site_title'])), $email_content['subject'], $email_content['content']);
                }

                if ($arr_admin_detail['role_id'] == 1) {

                    $user_account = $this->session->userdata('user_account');
                    $arr_admin_details = $this->common_model->getRecords("mst_users", "*", array("user_id" => $user_account['user_id']));
                    $arr_admin_details = end($arr_admin_details);
                    $user_account['user_name'] = stripslashes($arr_admin_details['user_name']);
                    $user_account['user_email'] = $arr_admin_details['user_email'];
                    $user_account['first_name'] = stripslashes($arr_admin_details['first_name']);
                    $user_account['last_name'] = stripslashes($arr_admin_details['last_name']);
                    $this->session->unset_userdata('admin_user_name');
                    $this->session->set_userdata('user_account', $user_account);
                    $this->session->set_userdata('admin_user_name', $user_account['user_name']);
                }

                $this->session->set_userdata("msg", "<span class='success'>Admin updated successfully!</span>");
                redirect(base_url() . "backend/admin/list");
            }
        }

        $arr_privileges = array();
        /* getting all privileges  */
        $data['arr_privileges'] = $this->common_model->getRecords('mst_privileges');
        /* getting admin details from $edit_id from function parameter */
        $data['arr_admin_detail'] = $this->common_model->getRecords("mst_users", "", array("user_id" => intval(base64_decode($edit_id))));
        /* single row fix */
        $data['arr_admin_detail'] = end($data['arr_admin_detail']);
        $data['title'] = "Update Admin User";
        $data['edit_id'] = $edit_id;
        $data['arr_roles'] = $this->common_model->getRecords("mst_role");
        $this->load->view('backend/admin/edit', $data);
    }

    /* function to display admin profile */

    public function adminProfile() {
        if (!$this->common_model->isLoggedIn()) {
            redirect(base_url() . "backend/login");
        }
        /* using the admin model */
        $this->load->model('admin_model');
        $data = $this->common_model->commonFunction();
        $arr_privileges = array();
        /* getting all privileges  */
        //$data['arr_privileges'] = $this->common_model->getRecords('mst_privileges');
        /* getting admin details from user id from function parameter */
        $user_account = $this->session->userdata('user_account');
       // $data['arr_admin_detail'] = $this->admin_model->getAdminDetails($user_account['user_id']);
       $data['arr_admin_detail'] = $this->common_model->getRecords('mst_users','',array('user_id'=>$user_account['user_id']));
        /* single row fix */
        $data['arr_admin_detail'] = end($data['arr_admin_detail']);
        $data['title'] = "Profile";
        $this->load->view('backend/admin/admin-profile', $data);
    }

    public function editProfile() {


        $user_account = $this->session->userdata('user_account');
        $edit_id = $user_account['user_id'];
        /* checking admin is logged in or not */
        if (!$this->common_model->isLoggedIn()) {
            redirect(base_url() . "backend/login");
        }
        $data = $this->common_model->commonFunction();
        if (count($_POST) > 0) {

            if ($this->input->post('user_name') != "") {
                $arr_admin_detail = $this->common_model->getRecords("mst_users", "", array("user_id" => intval($edit_id)));
                /* single row fix */
                $arr_admin_detail = end($arr_admin_detail);
                /* setting variable to update or add admin record. */
                if ($this->input->post('user_email') == $this->input->post('old_email')) {
                    $status = '1';
                    $email_verified = '1';
                    $activation_code = $arr_admin_detail['activation_code'];
                } else {

                    if ($arr_admin_detail['role_id'] != 1) {
                        $status = '0';
                        $email_verified = '0';
                        $activation_code = time();
                    } else {
                        $status = '1';
                        $email_verified = '1';
                        $activation_code = time();
                    }
                }
                if ($this->input->post('change_password') == 'on') {
                    $user_password = $_POST['user_password'];

                    /* if password need to change */
                    $arr_to_update = array(
                        "user_name" => $this->input->post('user_name'),
                        "first_name" => $this->input->post('first_name'),
                        "last_name" => $this->input->post('last_name'),
                        "user_email" => $this->input->post('user_email'),                       
                        "user_status" => $status,
                        'email_verified' => $email_verified,
                        'user_address'=>$this->input->post('address'),
                        'activation_code' => $activation_code
                    );
                } else {
                    $user_password = base64_decode($arr_admin_detail['user_password']);
                    /* if passwording need not need to change */
                    
                    $arr_to_update = array(
                        "user_name" => $this->input->post('user_name'),
                        "first_name" => $this->input->post('first_name'),
                        "last_name" => $this->input->post('last_name'),
                        "user_email" => $this->input->post('user_email'),                        
                        "user_status" => $status,
                       'user_address'=>$this->input->post('address'),
                        'email_verified' => $email_verified,
                        'activation_code' => $activation_code
                    );
                
                }
                /* updating the user details */
                $this->common_model->updateRow("mst_users", $arr_to_update, array("user_id" => $edit_id));

                if ($this->input->post('user_email') == $this->input->post('old_email')) {
                    if ($arr_admin_detail['role_id'] != 1) {
                        /* sending account updating mail to user */
                        $admin_login_link = '<a href="' . base_url() . 'backend/login" target="_new">Log in to ' . base_url() . 'administration</a>';

                        $macros_array_detail = array();
                        $macros_array_detail = $this->common_model->getRecords('mst_email_template_macros', 'macros,value', $condition_to_pass = '', $order_by = '', $limit = '', $debug = 0);
                        $macros_array = array();
                        foreach ($macros_array_detail as $row) {
                            $macros_array[$row['macros']] = $row['value'];
                        }
                        $reserved_words = array();
                        $reserved_arr = array
                            ("||SITE_TITLE||" => stripslashes($data['global']['site_title']),
                            "||SITE_PATH||" => base_url(),
                            "||USER_NAME||" => $this->input->post('user_name'),
                            "||ADMIN_NAME||" => $this->input->post('first_name') . ' ' . $this->input->post('last_name'),
                            "||ADMIN_EMAIL||" => $this->input->post('user_email'),
                            "||PASSWORD||" => $user_password,
                            "||ADMIN_LOGIN_LINK||" => $admin_login_link
                        );
                        $reserved_words = array_replace_recursive($macros_array, $reserved_arr);
                        /* getting mail subect and mail message using email template title and lang_id and reserved works */
                        $email_content = $this->common_model->getEmailTemplateInfo('admin-updated', 17, $reserved_words);
                        /* sending the mail to deleting user */
                        /* 1.recipient array. 2.From array containing email and name, 3.Mail subject 4.Mail Body */
                        $mail = $this->common_model->sendEmail(array($this->input->post('user_email')), array("email" => $data['global']['site_email'], "name" => stripslashes($data['global']['site_title'])), $email_content['subject'], $email_content['content']);
                    }
                } else {

                    /* sending account verification link mail to user */
                    $lang_id = 17;
                    $activation_link = '<a href="' . base_url() . 'backend/admin/account-activate/' . $activation_code . '">Activate Account</a>';
                    $macros_array_detail = array();
                    $macros_array_detail = $this->common_model->getRecords('mst_email_template_macros', 'macros,value', $condition_to_pass = '', $order_by = '', $limit = '', $debug = 0);
                    $macros_array = array();
                    foreach ($macros_array_detail as $row) {
                        $macros_array[$row['macros']] = $row['value'];
                    }
                    $reserved_words = array();
                    $reserved_arr = array
                        ("||SITE_TITLE||" => stripslashes($data['global']['site_title']),
                        "||SITE_PATH||" => base_url(),
                        "||USER_NAME||" => $this->input->post('user_name'),
                        "||ADMIN_NAME||" => $this->input->post('first_name') . ' ' . $this->input->post('last_name'),
                        "||ADMIN_EMAIL||" => $this->input->post('user_email'),
                        "||PASSWORD||" => $user_password,
                        "||ADMIN_ACTIVATION_LINK||" => $activation_link
                    );
                    $reserved_words = array_replace_recursive($macros_array, $reserved_arr);
                    /* getting mail subect and mail message using email template title and lang_id and reserved works */
                    $email_content = $this->common_model->getEmailTemplateInfo('admin-email-updated', 17, $reserved_words);
                    /* sending the mail to deleting user */
                    /* 1.recipient array. 2.From array containing email and name, 3.Mail subject 4.Mail Body */
                    $mail = $this->common_model->sendEmail(array($this->input->post('user_email')), array("email" => $data['global']['site_email'], "name" => stripslashes($data['global']['site_title'])), $email_content['subject'], $email_content['content']);

                    $this->session->set_userdata('msg', '<div class="alert alert-success">Your account is inactivated for email verification. Account activation link has been sent on updated email address.</div>');
                    $this->logout();
                }

                $user_account = $this->session->userdata('user_account');
                $arr_admin_details = $this->common_model->getRecords("mst_users", "*", array("user_id" => $user_account['user_id']));
                $arr_admin_details = end($arr_admin_details);
                $user_account['user_name'] = stripslashes($arr_admin_details['user_name']);
                $user_account['user_email'] = $arr_admin_details['user_email'];
                $user_account['first_name'] = stripslashes($arr_admin_details['first_name']);
                $user_account['last_name'] = stripslashes($arr_admin_details['last_name']);
                $this->session->set_userdata('user_account', $user_account);
                $this->session->set_userdata("msg", "<span class='success'>Profile has been updated successfully!</span>");
                redirect(base_url() . "backend/admin/profile");
            }
        }

        $arr_privileges = array();
        /* getting all privileges  */
        //$data['arr_privileges']=$this->common_model->getRecords('mst_privileges');
        /* getting admin details from $edit_id from function parameter */
        $data['arr_admin_detail'] = $this->common_model->getRecords("mst_users", "", array("user_id" => intval($edit_id)));
        /* single row fix */
        $data['arr_admin_detail'] = end($data['arr_admin_detail']);
        $data['title'] = "Edit Admin User";
        $data['edit_id'] = $edit_id;
        //$data['arr_roles'] = $this->common_model->getRecords("mst_role");
        $this->load->view('backend/admin/edit-profile', $data);
    }

}
