<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Web_services extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('common_model');
        $this->load->library('session');
// $this->load->model('employees_model');


        /*checking admin is logged in or not*/
//      if (!$this->common_model->isLoggedIn()) {
//          redirect(base_url() . "backend/login");
// exit();
//      }
    }
    public function ws_sign_in(){
        $name = $this->input->post('name');
        $mobile_no = $this->input->post('mobile_no');
        $password = $this->input->post('password');
        $email = $this->input->post('email');
        $check = 0;
        foreach($data as $data1){
            if($data1['l_mobile_no']===$mobile_no ){
                $check = 1;
            }
        }
        if($check != 0){
            $arr_loacation = array(
                'code'=>0,
                'msg'=>'User Already Exist',


// 'sign_in'=>$data,
            );
            echo json_encode($arr_loacation);
        }else{
            date_default_timezone_set('Asia/Kolkata');
            $date = date('Y/m/d H:i:s a'); 
            $arr_insert_id = array(
                'name' => $name,
                'l_mobile_no'=>$mobile_no,
                'password'=>$password,
                'log_email'=>$email,
               
            );
            //print_r($arr_insert_id); echo $data[0]['user_id']; exit();
            $last_insert_id = $this->common_model->insertRow($arr_insert_id,'login');
            $this->sendMailForNewCust($last_insert_id);
            if($last_insert_id){
                $data = array(
                    'id'=> $last_insert_id,
                    'name'=>$name,
                    'address'=>$address,
                    'mobile_no'=>$mobile_no,
                    'location_id'=>$location_id,
                    'route_id'=>$route_id,
                	'subad_id' => $data[0]['user_id'],'email'=>$email,);
                    

                    
                $sign_up=array($data);    

                $arr = array(
                    'code'=> 1,
                    'msg'=>'success',
                    'sing_up'=>$sign_up);
                
                echo json_encode($arr);
            }
        }
    }
      
     public function sendMailForNewCust($last_insert_id){
      $data = $this->common_model->getRecords('login','*', array('id' =>$last_insert_id));
        
        //echo $data[0]['log_email'];

                    $config = Array(        
                        'protocol' => 'sendmail',
                        'smtp_host' => 'http://localhost/new_test/',
                        'smtp_port' => 25,
                        'smtp_user' => 'santoshburungale0@gmail.com',
                        'smtp_pass' => '',
                        'smtp_timeout' => '4',
                        'mailtype'  => 'html', 
                        'charset'   => 'iso-8859-1'
                    ); 

            $ToEmail =  $data[0]['log_email'];//jmdinfotech.2000@gmail.com
            
            $subject = 'Verification  email';
            $this->load->library('email', $config);            
            $this->email->set_newline("\r\n");                
            $this->email->from('santoshburungale0@gmail.com', 'Verification');
            $this->email->to($ToEmail);  // replace it with receiver mail id            
            $this->email->subject($subject);       
            $data['form_data'] = $this->common_model->getRecords('login','*', array('id' =>$last_insert_id));     
              $body = 'welecome to sign up over application';           
            $this->email->message($body);
            $this->email->send();            
            return true;
    }

    public function ws_login(){
        $mobile_no = $this->input->post('mobile_no');

        $password = $this->input->post('password');

        $data = $this->common_model->getRecords('login','',array('l_mobile_no' => $mobile_no));

        $check = 0;
        if (empty($data)) {
            $arr_loacation = array(
                'code'=>0,
                'msg'=>'User Does Not Exist',);
            echo json_encode($arr_loacation);
        }
        else{
            foreach($data as $data1){
                if($data1['l_mobile_no']===$mobile_no && $data1['password']=== $password){
                    $check = 1;
                }
            }
            if($check == 0){
                $arr_loacation = array(
                    'code'=>0,
                    'msg'=>'Check User Name and Password',


// 'sign_in'=>$data,
                );
                echo json_encode($arr_loacation);
            }else{

                $data = array(
                    'id'=> $data[0]['id'],
                    'name'=>$data[0]['name'],
                    'mobile_no'=>$data[0]['l_mobile_no'],
                    'email'=>$data[0]['log_email']);
                    
                $login_date=array($data);        

                $arr = array(
                    'code'=> 1,
                    'msg'=>'success',
                    'login'=>$login_date);
                    
                echo json_encode($arr);
            }
        }
    }
}       
