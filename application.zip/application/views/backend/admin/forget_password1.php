<center>   <div class="col-md-3">
          <div id="msg1" style="display: none;">
          <p id="msg" style="font-size: 28px;color: green;"></p>
          <p id="msg2" style="font-size: 28px;color: red;"></p>
        </div>
      <?php

        $msg = $this->session->userdata('msg');
        $msg1 = $this->session->userdata('msg1');

        ?>
        <?php if ($msg != '') { ?>

            <div class="msg_box alert alert-success">

                <button type="button" class="close" data-dismiss="alert" id="msg_close" name="msg_close">X</button>

               <p style="color: green;font-size: 16px;"><i class="fa fa-check" style="font-size:30px;color:green;margin-right: 15px;" ></i> <?php echo $msg; ?></p>

               <?php $this->session->unset_userdata('msg');

                ?>
            </div>

        <?php } ?>
        <?php if ($msg1 != '') { ?>

            <div class="msg_box alert alert-success">

                <button type="button" class="close" data-dismiss="alert" id="msg_close" name="msg_close">X</button>

                <?php ?>

               <p style="color: red;font-size: 16px;"><i class="fa fa-close" style="font-size:30px;color:red;margin-right: 15px;"></i> <?php echo $msg1; ?></p>

               <?php $this->session->unset_userdata('msg1');

                ?>

            </div>

        <?php } ?>
      </div></center>