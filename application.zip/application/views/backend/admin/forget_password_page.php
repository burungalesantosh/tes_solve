<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<center style="margin-top: 10%;">
	         <div class="col-md-3">
          <div id="msg1" style="display: none;">
          <p id="msg" style="font-size: 28px;color: green;"></p>
          <p id="msg2" style="font-size: 28px;color: red;"></p>
        </div>
      <?php

        $msg = $this->session->userdata('msg');
        $msg1 = $this->session->userdata('msg1');

        ?>
        <?php if ($msg != '') { ?>

            <div class="msg_box alert alert-success">

                <button type="button" class="close" data-dismiss="alert" id="msg_close" name="msg_close">X</button>

               <p style="color: green;font-size: 16px;"><i class="fa fa-check" style="font-size:30px;color:green;margin-right: 15px;" ></i> <?php echo $msg; ?></p>

               <?php $this->session->unset_userdata('msg');

                ?>
            </div>

        <?php } ?>
        <?php if ($msg1 != '') { ?>

            <div class="msg_box alert alert-success">

                <button type="button" class="close" data-dismiss="alert" id="msg_close" name="msg_close">X</button>

                <?php ?>

               <p style="color: red;font-size: 16px;"><i class="fa fa-close" style="font-size:30px;color:red;margin-right: 15px;"></i> <?php echo $msg1; ?></p>

               <?php $this->session->unset_userdata('msg1');
               echo $data;
                ?>

            </div>

        <?php } ?>
      </div>

<div class="container">
  
  <p></p>
  <form action="<?php echo base_url();?>front/forget_password/<?php echo $id; ?>" method="POST" class=""id="form">
  	<div class="col-md-3" style=" border: 1px solid black" >
    <div class="form-group ">
      <label for="uname">New Password:</label>
      <input type="password" class="form-control" id="uname1" placeholder="Enter Password" name="password" required>
      
    </div>
    <div class="form-group">
      <label for="pwd">Confirm Password:</label>
      <input type="password" class="form-control"  id="pwd1" placeholder="Enter password" name="pswd" required>
     <div id="msg13"></div>
      
      <!-- <p class="msg12" id="msg12"></p> -->
      
    </div>
   
    
     <button  name="btn_submit" id="save" class="btn btn-primary " value="Save changes">Save</button>
</div>


  </form>
</div>
</center>
</body>
</html>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
<script type="text/javascript">
$("#pwd1").on("keyup", function () {

      var value = $('#pwd1').val();
      var value1 = $('#uname1').val();
      
if (value == value1) {
	$('#msg13').val('');
	//document.getElementById('msg12').style.display = 'none';
var error = "Password Match Successfully!";
        document.getElementById("msg13").innerHTML = error;

}else{
	$('msg13').val('');
	//document.getElementById('msg13').style.display = 'none';
	var error = "Password Do Not Match!";
        document.getElementById("msg13").innerHTML = error;
	

//$('#msg13').val('Password Do Not Match!');	
}

});
$(document).ready(function () {
        $('#form').submit(function() {
          var value = $('#pwd1').val();
      var value1 = $('#uname1').val();
      if (value == value1) {
      	return true;
      }else{
      	alert('Password Do Not Match');
      	return false;
      }
        });
    });

   
	
	
		function viewPassword()
		{
			var passwordInput = document.getElementById('password1');
			var passwordInput1 = document.getElementById('password2');
			var passStatus = document.getElementById('pass-status');
			var status1 = document.getElementById('status1');
			if (passwordInput.type == 'password'){
				passwordInput.type='text';
				passwordInput1.type='text';
				passStatus.style.display='none';
				status1.style.display='block';

			}
			else{
				passwordInput.type='password';
				passwordInput1.type='password';
//passStatus.className='fa fa-eye';
passStatus.style.display='block';
status1.style.display='none';
}
}
</script>