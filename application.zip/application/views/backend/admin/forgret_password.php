<!DOCTYPE html>

<html>

<head>

  <meta charset="utf-8" />

  <title>Thank you</title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

</head>

<body>

<div>
  <!--
    <div style="font-size: 26px;font-weight: 700;letter-spacing: -0.02em;line-height: 32px;color: #41637e;font-family: sans-serif;text-align: center" align="center" id="emb-email-header">
        <img style="border: 0;-ms-interpolation-mode: bicubic;display: block;Margin-right: auto;max-width: 200px" src="http://drnitinseducare.com/resources/images/logo.jpg" alt="" width="200" height="54">
    </div>
    -->
    <br />
    <br />
    <style>
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
    <div style="margin-left: 10%">
    <h2>Password reset information</h2>

<a href="<?php echo base_url();?>front/forget_password/<?php echo $form_data[0]['id'] ?>" style="background-color: #111111; color: white;margin: 4px 2px;display: inline-block;padding: 15px 32px">Click Here To Reset Password <i class="fas fa-forward"></i></a>
<p>After you click the button above, you'll be prompted to complete the following steps:</p>
<p>1. Enter new password.</p>
<p>2. Confirm your new password</p>
<p>3. Hit Submit</p>
<h3>This link is valid for one use only. It will expire in 2 hours.</h3>
<p>If you didn't request this password reset or you received this message in error, please disregard this email.</p>
</div>


<!-- 

<p> This IS test Mail </p>

<p> This IS test Mail </p>

<p> This IS test Mail </p> -->

</div>

</body>

</html>