<?php $this->load->view('backend/sections/header'); ?>
<?php $this->load->view('backend/sections/top-nav.php'); ?>
<?php $this->load->view('backend/sections/leftmenu.php'); ?>
<aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <?php if ($user_account['role_id'] == 1) { ?>
                    <h1>
                        Admin Dashboard
                        
                    </h1>
                <?php } ?>
                <?php if ($user_account['role_id'] == 2) { ?>
                    <h1>
                       Sub Admin Dashboard<br>
                       <?php echo $this->session->userdata('order_status'); ?>
                        
                    </h1>
                <?php } ?>
                    <ol class="breadcrumb">
                        <li class="active"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                       
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">

                    <!-- Small boxes (Stat box) -->
                    <div class="row">
                        <!-- ./col -->
                        <?php if ($user_account['role_id'] == 1) { ?>
                        

                       <div class="col-lg-3 col-xs-6">
                            <div class="small-box bg-yellow">
                                <div class="inner">
                                   
                                    <h3>
                                        <?php echo '&nbsp;';  ?>
                                    </h3>
                                    <p>
                                    Sub Admin List
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                 <a href="<?php echo  base_url() ?>sub_admin/listsubadmin" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                                
                            </div>
                        </div> 
                        <div class="col-lg-3 col-xs-6">
                            <div class="small-box bg-yellow">
                                <div class="inner">
                                   
                                    <h3>
                                        <?php echo '&nbsp;';  ?>
                                    </h3>
                                    <p>
                                    Product Master List
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                 <a href="<?php echo  base_url() ?>product/listproduct" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                                
                            </div>
                        </div> 
                        <div class="col-lg-3 col-xs-6">
                            <div class="small-box bg-yellow">
                                <div class="inner">
                                   
                                    <h3>
                                        <?php echo '&nbsp;';  ?>
                                    </h3>
                                    <p>
                                    Location Master List
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                 <a href="<?php echo  base_url() ?>location_master/listevloaction" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                                
                            </div>
                        </div> 
                        <div class="col-lg-3 col-xs-6">
                            <div class="small-box bg-yellow">
                                <div class="inner">
                                   
                                    <h3>
                                        <?php echo '&nbsp;';  ?>
                                    </h3>
                                    <p>
                                    Product Issue List
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                 <a href="<?php echo  base_url() ?>product_issue_entry/list_product_issue" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                                
                            </div>
                        </div> 
                           <?php $count = array(); $count1= array(); $i = '';$j =''; foreach ($subadmin_master as $data) { $i=0;
                            foreach ($login as $data1) {
                                if ($data1['subad_id'] == $data['user_id']) {
                                   $i = $i+1;
                                }
                            }
                            $count[] = $i;

                        } 
                        for ($j=0; $j < count($subadmin_master); $j++) { 
                         $total_price = 0;
                          foreach ($login as $data4) {
                            // echo $subadmin_master[$j]['user_id'];echo '&nbsp';echo '&nbsp';echo '&nbsp';
                            // echo $data4['subad_id']; 
                           if ($data4['subad_id'] === $subadmin_master[$j]['user_id']) {
                            

                                foreach ($entry as $data5) {
                                  if ($data4['id'] === $data5['users_id']) {
                                    //echo $data5['users_id'];echo "<br>";
                                    $total_price = $total_price + $data5['total_price'];
                                  }
                                }//echo $total_price;
                              
                                
                              
                             }
                           }$count1[] = $total_price; //echo $total_price;
                         }$total_price = 0;
                           
                           
                           
                          
                          
                           
                          
                          
                         ?>
                        <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
                        <div class="col-lg-6">
                        <H4>Sub Admin wise Customer Count</H4>
                        <div id="myfirstchart" style="height: 250px;"></div>

                    </div>
                    <div class="col-lg-6">
                        <H4>Sub Admin Sale </H4>
                        <div id="myfirstchart1" style="height: 250px;"></div>
                        
                    </div>
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
<script type="text/javascript">
    new Morris.Bar({
  // ID of the element in which to draw the chart.
  element: 'myfirstchart',
  // Chart data records -- each entry in this array corresponds to a point on
  // the chart.
   data: [
  <?php for($i = 0;$i< count($subadmin_master); $i++): ?>
     
    { name: '<?php echo $subadmin_master[$i]['last_name']; ?>', value: '<?php echo $count[$i]; ?>' },
    
    
  
  <?php endfor ?>
  ],
  // data: [
  //   { year: '2008', value: 20 },
  //   { year: '2009', value: 10 },
  //   { year: '2010', value: 5 },
  //   { year: '2011', value: 5 },
  //   { year: '2012', value: 20 }
  // ],
  // The name of the data record attribute that contains x-values.
  xkey: 'name',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Value']

});

</script>  
<script type="text/javascript">
    new Morris.Bar({
  // ID of the element in which to draw the chart.
  element: 'myfirstchart1',
  // Chart data records -- each entry in this array corresponds to a point on
  // the chart.
   data: [
  <?php for($j = 0;$j< count($subadmin_master); $j++): ?>
     
    { name: '<?php echo $subadmin_master[$j]['last_name']; ?>', value: '<?php echo $count1[$j]; ?>' },
    
    
  
  <?php endfor ?>
  ],
  // data: [
  //   { year: '2008', value: 20 },
  //   { year: '2009', value: 10 },
  //   { year: '2010', value: 5 },
  //   { year: '2011', value: 5 },
  //   { year: '2012', value: 20 }
  // ],
  // The name of the data record attribute that contains x-values.
  xkey: 'name',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Value']

});

</script>           
                    <?php }elseif($user_account['role_id'] == 2){?>
                        
<div class="col-lg-3 col-xs-6">
                            <div class="small-box bg-blue">
                                <div class="inner">
                                   
                                    <h3><?php if (empty(count($accept))) {
                                    echo "0";
                                    }else{
                                      echo count($accept);
                                    } ?>
                                    </h3>
                                    <p>
                                    ACCEPT ORDER
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                 <a href="<?php echo  base_url() ?>orderd_product/Active" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                                
                            </div>
                        </div> 
                        <div class="col-lg-3 col-xs-6">
                            <div class="small-box bg-yellow">
                                <div class="inner">
                                   
                                    <h3><?php if (empty(count($Shipped))) {
                                    echo "0";
                                    }else{
                                      echo count($Shipped);
                                    } ?>
                                    </h3>
                                    <p>
                                    SHIPPED ORDER
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                 <a href="<?php echo  base_url() ?>orderd_product/Shipped" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                
                            </div>
                        </div> 
                        <div class="col-lg-3 col-xs-6">
                            <div class="small-box bg-green">
                                <div class="inner">
                                   
                                    <h3><?php if (empty(count($Delivered))) {
                                    echo "0";
                                    }else{
                                      echo count($Delivered);
                                    } ?>
                                    </h3>
                                    <p>
                                    DELIVERED ORDER
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                 <a href="<?php echo  base_url() ?>orderd_product/Complete" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                                
                            </div>
                        </div> 
                        <div class="col-lg-3 col-xs-6">
                            <div class="small-box bg-red">
                                <div class="inner">
                                   
                                    <h3><?php if (empty(count($Cancelled))) {
                                    echo "0";
                                    }else{
                                      echo count($Cancelled);
                                    } ?>
                                    </h3>
                                    <p>
                                    CANCELLED ORDER
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                 <a href="<?php echo  base_url() ?>orderd_product/cancelled" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                                
                            </div>
                        </div>
 <script type="text/javascript">
            function changeStatus(user_id, user_status)
            {
                /* changing the user status*/
                var obj_params = new Object();
                obj_params.user_id = user_id;
                obj_params.user_status = user_status;
                jQuery.post("<?php echo base_url(); ?>backend/user/change-status", obj_params, function (msg) {
                    if (msg.error == "1")
                    {
                        alert(msg.error_message);
                    }
                    else
                    {
                        /* togling the bloked and active div of user*/
                        if (user_status == 2)
                        {
                            $("#blocked_div" + user_id).css('display', 'inline-block');
                            $("#active_div" + user_id).css('display', 'none');
                        }
                        else
                        {
                            $("#active_div" + user_id).css('display', 'inline-block');
                            $("#blocked_div" + user_id).css('display', 'none');
                        }
                    }
                }, "json");

            }
            function changeEmailVerified(user_id, user_email_verified)
            {
                /* changing the user status*/
                var obj_params = new Object();
                obj_params.user_id = user_id;
                obj_params.user_email_verified = user_email_verified;
                jQuery.post("<?php echo base_url(); ?>backend/user/change-status-email", obj_params, function (msg) {
                    if (msg.error == "1")
                    {
                        alert(msg.error_message);
                    }
                    else
                    {
                        /* togling the bloked and active div of user*/
                        if (user_email_verified == 1)
                        {
                            location.reload();
                            $("#active_div_email" + user_id).css('display', 'inline-block');
                            $("#inactive_div_email" + user_id).css('display', 'none');
                        }
                        else
                        {
                            location.reload();
                            $("#inactive_div_email" + user_id).css('display', 'inline-block');
                            $("#active_div_email" + user_id).css('display', 'none');
                        }
                    }
                }, "json");

            }
            setTimeout(function() {
  location.reload();
}, 30000);
        </script>
        <meta http-equiv="refresh" content="60"/>
          <style type="text/css">
      #myTable {
        height: 1000px;
        display: inline-block;
        width: 100%;
        overflow: auto;
        border-collapse: collapse;

        font-size: 16px;

      }
      h3 input.search-input {
        width: 300px;

        float: left;
      }
      h3 span{
        width: 300px;

        float: center;
      }
       .loader {
  border: 16px solid #f3f3f3;

  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 100px;
  height: 100px;
 
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}
    </style>
                                          <div class="row">
      <div class="col-xs-12">
        <div class="box">
           <div class="modal fade" id="myModal1245" role="dialog">
        <div class="modal-dialog" >
    
      <!-- Modal content-->
      <div class="modal-content">
        
        <div class="modal-body">
        <div class="row">
          <div class="form-group col-md-4">
                  <div class="form-row">
                    <label for="txtProdName">Reason<sup class="mandatory">*</sup></label>
                    <textarea name="reson" id="reson"class="form-control" style="text-transform: capitalize;"></textarea>
                     <!--      <input class="form-control" type="text" id="reson" name="reson"autoComplete ="off"
                          aria-describedby="nameHelp" placeholder="Enter Product Name" required="Enter Product Name" style="text-transform: capitalize;" > -->
                          <input type="hidden" name="order_id"id="order_id">
                  </div>
                </div><!-- end of form control 1--->
               </div> 
             </div>

        <div class="modal-footer">
          <button  name="btn_submit" id="save_reson" class="btn btn-primary " value="Save changes">Save</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        </div>
      </div>      
    </div>
  </div>
</div>
          <form name="frm_admin_users" id="frm_admin_users" action="<?php echo base_url(); ?>orderd_product/search" method="post"enctype="multipart/form-data">
            <div class="box-body table-responsive">
              <div role="grid" class="dataTables_wrapper form-inline" id="example1_wrapper">                  
                <table class="table table-bordered  dataTable" id="myTable">
                  <thead>
                    <tr role="row">
                        <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Order No </th>
                                <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Order Date </th>
                                <?php if( $order_entryhd[0]['status'] == 'Processing'){ ?>
                                 <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Accept Date</th>
                                 <?php } elseif($order_entryhd[0]['status'] == 'Shipped'){?>
                                  <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Shipped Date</th>
                                 <?php } elseif($order_entryhd[0]['status'] == 'Cancelled'){?>
                                  <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Cancelled Date</th>
                                 <?php } elseif($order_entryhd[0]['status'] == 'Delivered'){?>
                                  <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Delivered Date</th>
                                 <?php } ?>
                                
                                <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Customer Name </th>
                                
                                

                                <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Address</th>
                                <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Mobile No</th>
                                <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Order Value</th>
                                <?php if($order_entryhd[0]['status'] == 'Cancelled'){?>
                                  <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Reason</th>
                                <?php } ?>
                                <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Auto Driver Name</th>

                                <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Driver Mobile No</th>
                                <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Status </th>
                                <?php if ($user_account['role_id'] == 2) { ?>
                                  
                              
                                <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"  aria-sort="ascending" aria-label="Username">Action</th>

                                 <?php   } ?>
                          </tr>
                  </thead>

                  <tbody>
                    <?php  $total_price = 0; $i = 0; foreach ($order_entryhd as $details) {
                                      if($user_account['user_id'] == $details['subad_id']) { $total_price = $total_price + $details['total_price']; ?>
                                      <tr>
                                  <td><a href="<?php echo base_url();?>orderd_product/sub_orderdetails/<?php echo $details['order_id']; ?>"><?php echo $details['order_id']; ?></a></td>
                                  <td style="width: 10%"><?php echo date('d-m-Y H:i:s',strtotime($details['date'])); ?></td>
                                  <?php if( $details['status'] == 'Processing'){ ?>
                                    <td> <?php if ($details['accept_date']!="0000-00-00 00:00:00") { echo date('d-m-y H:i:s',strtotime($details['accept_date']));}else{echo "";}
                                    ?></td><?php } elseif($details['status'] == 'Shipped'){?>
                                      <td> <?php if ($details['shipped_date']!="0000-00-00 00:00:00") {echo date('d-m-y H:i:s',strtotime($details['shipped_date']));}else{echo "";}
                                    ?></td><?php } elseif($details['status'] == 'Cancelled'){?>
                                      <td> <?php if ($details['cancelled_date']!="0000-00-00 00:00:00") { echo date('d-m-y H:i:s',strtotime($details['cancelled_date']));}else{echo "";}
                                    ?></td><?php } elseif($details['status'] == 'Delivered') { ?>
                                    <td> <?php if ($details['delivery_date']!="0000-00-00 00:00:00") { echo date('d-m-y H:i:s',strtotime($details['delivery_date']));}else{echo "";}
                                    ?></td><?php } ?>
                                  
                                   <td><?php echo $details['name']; ?></td>
                                    <td><?php echo $details['delivery_address']; ?></td> 
                                    <td><?php echo $details['l_mobile_no']; ?></td>
                                    <td style="text-align: right;"><?php echo $details['total_price']; ?></td>
                                    <?php if ($details['status'] === 'Cancelled') { ?>
                                      <td><?php echo $details['resion']; ?></td>
                                    <?php } ?>
                                    <td><?php echo $details['driver_name']; ?></td>
                                    <td><?php echo $details['driver_mobile_no']; ?></td>
                                    
                                  <?php if( $details['status'] == 'Processing'){ ?>
                                    <td style="color: orange;"> <?php echo $details['status'];
                                    ?></td><?php } elseif($details['status'] == 'Shipped'){?>
                                      <td style="color: yellow;"> <?php echo $details['status'];
                                    
                                      ?></td><?php } elseif( $details['status'] == 'Received'){ ?>
                                  <td style="color: blue;"> <?php echo $details['status'];
                                    ?></td><?php } elseif($details['status'] == 'Cancelled'){?>
                                      <td style="color: red;"> <?php echo $details['status'];
                                    ?></td><?php } elseif($details['status'] == 'Delivered') { ?>
                                    <td style="color: green;"> <?php echo $details['status'];
                                    ?></td><?php } ?>
                                  <?php if ($user_account['role_id']== 2) {
                                    if ($details['status'] == 'Cancelled') { ?>
                                    <td class="worktd"><a class="btn btn-info " title="Edit User Details" href="<?php echo base_url(); ?>orderd_product/accept/<?php echo $details['prod_id1']; ?>" readonly =""> <i class="icon-edit icon-white"></i>Accept</a></td>

                                  <?php } elseif ($details['status'] == 'Processing') { ?>
                                    <td class="worktd"><a class="btn btn-info " title="Edit User Details" href="<?php echo base_url(); ?>orderd_product/sub_shipped/<?php echo $details['prod_id1']; ?>"> <i class="icon-edit icon-white"></i>Shipped</a></td>
                                 <?php } elseif($details['status'] == 'Shipped'){ ?>
                                  <td class="worktd"><a class="btn btn-info " title="Edit User Details" href="<?php echo base_url(); ?>orderd_product/sub_delivered/<?php echo $details['prod_id1']; ?>"> <i class="icon-edit icon-white"></i>In Transit</a></td>
                                    <?php } elseif($details['status'] == 'Delivered'){ ?>
                                  <td class="worktd"><a class="btn btn-info disabled" title="Edit User Details" href="<?php echo base_url(); ?>orderd_product/accept/<?php echo $details['prod_id1']; ?>"> <i class="icon-edit icon-white"></i>Complete</a></td>
                                  <?php } elseif($details['status'] == 'Received'){ ?>
                                    <td class="worktd"><a class="btn btn-info" title="Edit User Details" href="<?php echo base_url(); ?>orderd_product/accept/<?php echo $details['prod_id1']; ?>"> <i class="icon-edit icon-white"></i>Accept</a>
                                    <a class="btn btn-info cancel_order" id="<?php echo $details['prod_id1'];?>"href="javascript:void(0)">cancel</a></td></tr>
                                 <?php }  ?>
                             <?php  } $i++; } ?>
                        <?php  }  ?>
                        <tr>
                          <td>Total : </td>
                          <td></td>
                          <td></td>
                          <td></td>
                          <td></td>
                          <?php if( $order_entryhd[0]['status'] != 'Received'){ ?>
                          <td></td>
                        <?php }?>
                          <td style="text-align: right;"><?php echo $total_price; ?></td>
                          <?php if( $order_entryhd[0]['status'] == 'Cancelled'){ ?>
                            <td></td>
                          <?php } ?>
                          <td></td>
                          <td></td>
                          <td></td>
                          <td></td>
                        </tr>

                    
                </tbody>

                <tfoot>
                         <!-- <form action="<?php echo base_url();?>" method="post" >
                                          <div class="col-xs-12">
                                            <div class="row">
                                              <div class="col-lg-2">
                                              <label >Select Status</label>
                                              <select name="status" >
                                                <option value="1">All Orders</option>
                                                <option value="2">Active Orders</option>
                                                <option value="3">Completed Orders</option>
                                                <option value="4">Cancelled Orders </option>
                                              </select>
                                             
                                              </div> 
                                              <div class="col-lg-3"><br>
                                               <input type="submit" name="submit" class="btn btn-primary"> 
                                              </div>                                            
                                            </div>
                                        </form> 
                                        <br><hr style="border-bottom: 1px solid black;"/>    -->         
                  <h3>
                  <input type="search" placeholder="Search..." class="form-control search-input" data-table="dataTable"/>
                  <label style="font-size: 16px">Total Records Found : <?php echo $i; ?></label>
              </h3> <div class="col-md-6">
      <div id="msg1" style="display: none;">
        <p id="msg" style="font-size: 28px;color: green;"></p>
        <p id="msg2" style="font-size: 28px;color: red;"></p>
      </div>
      <?php

      $msg = $this->session->userdata('msg');
      $msg1 = $this->session->userdata('msg1');

      ?>
      <?php if ($msg != '') { ?>

        <div class="msg_box alert alert-success">

          <button type="button" class="close" data-dismiss="alert" id="msg_close" name="msg_close">X</button>

          <p style="color: green;font-size: 16px;"><i class="fa fa-check" style="font-size:30px;color:green;margin-right: 15px;" ></i> <?php echo $msg; ?></p>

          <?php $this->session->unset_userdata('msg');

          ?>
        </div>

      <?php } ?>
      <?php if ($msg1 != '') { ?>

        <div class="msg_box alert alert-success">

          <button type="button" class="close" data-dismiss="alert" id="msg_close" name="msg_close">X</button>

          <?php ?>

          <p style="color: red;font-size: 16px;"><i class="fa fa-close" style="font-size:30px;color:red;margin-right: 15px;"></i> <?php echo $msg1; ?></p>

          <?php $this->session->unset_userdata('msg1');

          ?>

        </div>

      <?php } ?>
    </div>
              
                </tfoot>

              </table>

            </div>
          </div>
          <div class="modal fade" id="myModal12" role="dialog" style="margin-top: 15%;margin-left: 50%; width: 100%" >
  <div class="loader"></div>   
    
  </div>
        </form>

        
      </div>
    </div>
   <?php } ?>

            
                    </div><!-- /.row -->

                  

                  
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
 
 $(".cancel_order").click(function(){
 var pincode = $(this).attr('id');
 $('#order_id').val(pincode);
$("#myModal1245").modal();
  
  });
 $('#save_reson').click(function(){
  var order_id  = $('#order_id').val();
  var reson = $('#reson').val();
  if (reson === '') {
    alert('reson don Not Empty');
    return false;
  }else{
    $("#myModal1245").modal('toggle');
    $("#myModal12").modal();
    $.ajax({
    url:'<?=base_url()?>orderd_product/cancel',
    method: 'post',
    data: {order_id:order_id,reson:reson},
    dataType: 'json',
    success: function(response){
      console.log(response);
      $("#myModal12").modal('toggle');
      reloadPage();


    }
  });
  }
  
 })
 function reloadPage(){
    location.reload(true);
  }
  
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <?php $this->load->view('backend/sections/footer.php'); ?>
<script type="text/javascript">
  (function(document) {
    'use strict';

    var TableFilter = (function(myArray) {
      var search_input;

      function _onInputSearch(e) {
        search_input = e.target;
        var tables = document.getElementsByClassName(search_input.getAttribute('data-table'));
        myArray.forEach.call(tables, function(table) {
          myArray.forEach.call(table.tBodies, function(tbody) {
            myArray.forEach.call(tbody.rows, function(row) {
              var text_content = row.textContent.toLowerCase();
              var search_val = search_input.value.toLowerCase();
              row.style.display = text_content.indexOf(search_val) > -1 ? '' : 'none';
            });
          });
        });
      }

      return {
        init: function() {
          var inputs = document.getElementsByClassName('search-input');
          myArray.forEach.call(inputs, function(input) {
            input.oninput = _onInputSearch;
          });
        }
      };
    })(Array.prototype);

    document.addEventListener('readystatechange', function() {
      if (document.readyState === 'complete') {
        TableFilter.init();
      }
    });

  })(document);
</script>
 