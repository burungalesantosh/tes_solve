<!-- Left side column. contains the logo and sidebar -->
<aside class="left-side sidebar-offcanvas">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- <link href="/your-path-to-fontawesome/css/fontawesome.css" rel="stylesheet">
        <link href="/your-path-to-fontawesome/css/brands.css" rel="stylesheet">
        <link href="/your-path-to-fontawesome/css/solid.css" rel="stylesheet"> -->
        <script defer src="https://use.fontawesome.com/releases/v5.12.0/js/all.js"></script>
        <script defer src="https://use.fontawesome.com/releases/v5.12.0/js/v4-shims.js"></script>
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <!--<div class="pull-left image">
                <img src="img/avatar3.png" class="img-circle" alt="User Image" />
            </div>-->
            <div class="pull-left info">
                <p>Hello, <?php echo $user_account['last_name']; ?></p>
                <a href="javascript:void(0);"><i class="fa fa-circle text-success"></i> Logged In</a>
            </div>
        </div>
        <!-- search form -->
        <form action="" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search..."/>
                <span class="input-group-btn">
                    <button type='button' name='seach' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
                </span>
            </div>
        </form>
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <?php if ($user_account['role_id'] == 1) { ?>
            <ul class="sidebar-menu">
                <li <?php if ($this->uri->segment(2) == 'dashboard') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>backend/dashboard">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="ion ion-person-add"></i>
          <span>Master<i class="caret" style="margin-left: 15px"></i></span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded"><br>
            <a href="<?php echo base_url(); ?>sub_admin/listsubadmin" style="margin-left: 15px" >
                       <i class="fas fa-users"></i> <span>Sub-Admin Master</span>
                   </a><br><br>
                   <a href="<?php echo base_url(); ?>product/listproduct"style="margin-left: 15px">
                        <i class="fas fa-cart-plus"></i> <span>Product Master</span>
                    </a><br><br>
                    <a href="<?php echo base_url(); ?>location_master/listevloaction" style="margin-left: 15px" >
                        <i class="fas fa-map-marker-alt"></i> <span>Location Master</span>
                    </a><br><br>
                    <a href="<?php echo base_url(); ?>slider/listslider" style="margin-left: 15px" >
                        <i class="fas fa-map-marker-alt"></i> <span>Slider Master</span>
                    </a><br><br>
                    <a href="<?php echo base_url(); ?>slider/listsliderbottom" style="margin-left: 15px" >
                        <i class="fas fa-map-marker-alt"></i> <span>Bottom Slider Master</span>
                    </a><br><br>
            <div class="collapse-divider"></div>
          </div>
        </div>
      </li>
           <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages1" aria-expanded="true" aria-controls="collapsePages1">
          <i class="ion ion-person-add"></i>
          <span>Transactions<i class="caret" style="margin-left: 15px"></i></span>
        </a>
        <div id="collapsePages1" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded"><br>
            <a href="<?php echo base_url(); ?>product_issue_entry/list_product_issue"style="margin-left: 15px">
                       <i class="fas fa-people-carry"></i> <span>Product Issue Entry</span>
                   </a><br><br>
                   <!-- <a href="<?php echo base_url(); ?>product/listproduct">
                        <i class="fas fa-cart-plus"></i> <span>Product Master</span>
                    </a><br> -->
            <div class="collapse-divider"></div>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages3" aria-expanded="true" aria-controls="collapsePages3">
          <i class="ion ion-person-add"></i>
          <span>Utilities<i class="caret" style="margin-left: 15px"></i></span>
        </a>
        <div id="collapsePages3" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar3">
          <div class="bg-white py-2 collapse-inner rounded"><br>
           <a href="<?php echo base_url(); ?>sub_admin/change_password" style="margin-left: 15px">
                        <i class="fas fa-people-carry"></i> <span>Change Password</span>
                    </a><br><br>
                   <!--<a href="<?php echo base_url(); ?>product/listproduct">
                        <i class="fas fa-cart-plus"></i> <span>Product Master</span>
                    </a><br> -->
            <div class="collapse-divider"></div>
          </div>
        </div>
      </li>
           <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages2" aria-expanded="true" aria-controls="collapsePages2">
          <i class="ion ion-person-add"></i>
          <span>Reports<i class="caret" style="margin-left: 15px"></i></span>
        </a>
        <div id="collapsePages2" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded"><br>
            <a href="<?php echo base_url(); ?>orderd_product/listorder"style="margin-left: 15px">
              <?php $this->session->set_userdata("Total Order Report", "Total Order Report"); ?>
                       <i class="fas fa-users"></i> <span>Total Order Report</span>
                   </a><br><br>
                   <a href="<?php echo base_url(); ?>orderd_product/orderstatus_list"style="margin-left: 15px">
                       <i class="fas fa-users"></i> <span>Order status Report</span>
                   </a><br><br>
                   <a href="<?php echo base_url(); ?>orderd_product/product_sell_report"style="margin-left: 15px">
                    <?php $this->session->set_userdata("Product Sell Reprot", "Product Sale Report"); ?>
                       <i class="fas fa-users"></i> <span>Product Sale Report</span>
                   </a><br><br>
                   <a href="<?php echo base_url(); ?>orderd_product/product_issue_report"style="margin-left: 15px">
                    <?php $this->session->set_userdata("Product Issue", "Product Issue Report"); ?>
                       <i class="fas fa-users"></i> <span>Product Issue Report</span>
                   </a><br><br>
                    <a href="<?php echo base_url(); ?>orderd_product/customer_list"style="margin-left: 15px">
                       <i class="fas fa-users"></i> <span>Customer List</span>
                   </a><br><br>
                   <a href="<?php echo base_url(); ?>orderd_product/customer_wise_order_summary"style="margin-left: 15px">
                       <i class="fas fa-users"></i> <span>Customer Wise Order Summary</span>
                   </a><br><br>
                   <a href="<?php echo base_url(); ?>orderd_product/customer_wise_null_order_summary"style="margin-left: 15px">
                       <i class="fas fa-users"></i> <span>Customer Nil Order</span>
                   </a><br><br>
                   <a href="<?php echo base_url(); ?>orderd_product/priviusdateorder_summay"style="margin-left: 15px">
                       <i class="fas fa-users"></i> <span>Next Day  Product Order</span>
                   </a><br><br>
                  <!-- <a href="<?php echo base_url(); ?>product/listproduct">
                        <i class="fas fa-cart-plus"></i> <span>Product Master</span>
                    </a><br>-->
            <div class="collapse-divider"></div>
          </div>
        </div>
      </li>
           <!--      <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                   <a href="<?php echo base_url(); ?>sub_admin/listsubadmin">
                       <i class="fas fa-users"></i> <span>Sub-Admin Master</span>
                   </a>
               </li>

                <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>product/listproduct">
                        <i class="fas fa-cart-plus"></i> <span>Product Master</span>
                    </a>
                </li>
 -->
                
                <!-- <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                   <a href="<?php echo base_url(); ?>product_issue_entry/list_product">
                       <i class="fas fa-people-carry"></i> <span>Product Issue Entry</span>
                   </a>
               </li> -->
                
                <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>notification/listNotifications">
                        <i class="fas fa-comment-alt"></i> <span>Notification</span>
                    </a>
                </li>

                

               <!--  <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>StaffController/listStaff">
                        <i class="fa fa-dashboard"></i> <span>Manage Staff</span>
                    </a>
                </li> -->
                                   
            </ul>
            <?php
        }elseif($user_account['role_id'] == 2){?>
        <ul class="sidebar-menu">
            <li <?php if ($this->uri->segment(2) == 'dashboard') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>backend/dashboard">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>
                 <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages1" aria-expanded="true" aria-controls="collapsePages1">
          <i class="ion ion-person-add"></i>
          <span>Master<i class="caret" style="margin-left: 15px"></i></span>
        </a>
        <div id="collapsePages1" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded"><br>
            
                    <a href="<?php echo base_url(); ?>route_master/listroutemaster"style="margin-left: 15px">
                      <?php $this->session->set_userdata('Route Master','Route Master'); ?>
                        <i class="fas fa-route"></i> <span>Route Master</span>
                    </a><br><br>
                    <a href="<?php echo base_url(); ?>transport_master/list_transport"style="margin-left: 15px">
                      <?php $this->session->set_userdata('Auto Driver Master','Auto Driver Master'); ?>
                        <i class="fas fa-shipping-fast"></i> <span>Auto Driver Master</span>
                    </a><br><br>
                   <!-- <a href="<?php echo base_url(); ?>product/listproduct">
                        <i class="fas fa-cart-plus"></i> <span>Product Master</span>
                    </a><br> -->
            <div class="collapse-divider"></div>
          </div>
        </div>
      </li>
         <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages2" aria-expanded="true" aria-controls="collapsePages2">
          <i class="ion ion-person-add"></i>
          <span>Reports<i class="caret" style="margin-left: 15px"></i></span>
        </a>
        <div id="collapsePages2" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded"><br>
           <a href="<?php echo base_url(); ?>product_issue_entry/list_product" style="margin-left: 15px">
                        <i class="fas fa-people-carry"></i> <span>Product Details</span>
                    </a><br><br>
                    <a href="<?php echo base_url(); ?>orderd_product/sub_listorder"style="margin-left: 15px">
              <?php $this->session->set_userdata("Total Order Report", "Total Order Report"); ?>
                       <i class="fas fa-users"></i> <span>Total Order Report</span>
                   </a><br><br>
                    <!-- <a href="<?php echo base_url(); ?>orderd_product/listorder"style="margin-left: 15px">
                       <i class="fas fa-users"></i> <span>Order Master</span>
                   </a><br><br> -->
                   <!--<a href="<?php echo base_url(); ?>product/listproduct">
                        <i class="fas fa-cart-plus"></i> <span>Product Master</span>
                    </a><br> -->
            <div class="collapse-divider"></div>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages3" aria-expanded="true" aria-controls="collapsePages3">
          <i class="ion ion-person-add"></i>
          <span>Utilities<i class="caret" style="margin-left: 15px"></i></span>
        </a>
        <div id="collapsePages3" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar3">
          <div class="bg-white py-2 collapse-inner rounded"><br>
           <a href="<?php echo base_url(); ?>sub_admin/change_password" style="margin-left: 15px">
                        <i class="fas fa-people-carry"></i> <span>Change Password</span>
                    </a><br><br>
                   <!--<a href="<?php echo base_url(); ?>product/listproduct">
                        <i class="fas fa-cart-plus"></i> <span>Product Master</span>
                    </a><br> -->
            <div class="collapse-divider"></div>
          </div>
        </div>
      </li>
        
           <!--      <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>location_master/listevloaction">
                        <i class="fas fa-map-marker-alt"></i> <span>Location Master</span>
                    </a>
                </li>

                <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>route_master/listroutemaster">
                        <i class="fas fa-route"></i> <span>Route Master</span>
                    </a>
                </li>

                <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>transport_master/list_transport">
                        <i class="fas fa-shipping-fast"></i> <span>Transport Master</span>
                    </a>
                </li>
            -->     <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>notification/sublistNotifications">
                        <i class="fas fa-comment-alt"></i> <span>Notification</span>
                    </a>
                </li>
               <!--  <li <?php if ($this->uri->segment(2) == 'user') { ?> class="active" <?php } ?>>
                    <a href="<?php echo base_url(); ?>product_issue_entry/list_product">
                        <i class="fas fa-people-carry"></i> <span>Product Details</span>
                    </a>
                </li> -->
            </ul>
        <?php } ?>
        
        
    </section>
    <!-- /.sidebar -->
</aside>

<!-- Right side column. Contains the navbar and content of the page -->
