<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Common_Model extends CI_Model {
    /*function to get global setttings from the database */	

    function array_values_recursive($arr){        
        $arr = array_values($arr);        
        foreach($arr as $key => $val)            
            if(array_values($val) === $val)                
                $arr[$key] = array_values_recursive($val);               
                 return $arr;	
    }
	
	function visitorCounter() {

        $this->db->set('count', 'count+1', FALSE);
        $this->db->update('website_counter');
        return true;
    } 

    function findExtension($filename) {
        $filename = strtolower($filename);
        $file = str_replace(" ", "-", $filename);
        $exts = explode(".", $file);
        $file_name = '';
        for ($i = 0; $i <= count($exts) - 2; $i++) {
            $file_name .=$exts[$i];
        }
        $n = count($exts) - 1;
        $exts = $exts[$n];
        $arr_return = array(
            'file_name' => $file_name,
            'ext' => $exts
        );
        return $arr_return;
    }

    public function getGlobalSettings($lang_id = '') {
        $global = array();
        $this->db->select('mst_global.*,trans_global.*');
        $this->db->from('mst_global_settings as mst_global');
        $this->db->join('trans_global_settings as trans_global', 'mst_global.global_name_id = trans_global.global_name_id', 'left');
        if ($lang_id != '') {
            $this->db->where("trans_global.lang_id", $lang_id); /* for lnag id passed ie. english */
        } else {
            $this->db->where("trans_global.lang_id", 17); /* for default language ie. english */
        }
        $result = $this->db->get();
        foreach ($result->result_array() as $row) {
            $global[$row['name']] = $row['value'];
        }
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'getGlobalSettings',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return $global;
    }
    public function compress_image($source_url, $destination_url, $quality) {
        $info = getimagesize($source_url);
        if ($info['mime'] == 'image/jpeg') {
            $image = imagecreatefromjpeg($source_url);
        } elseif ($info['mime'] == 'image/gif') {
            $image = imagecreatefromgif($source_url);
        } elseif ($info['mime'] == 'image/png') {
            $image = imagecreatefrompng($source_url);
        }
        imagejpeg($image, $destination_url, $quality);
        $image_info = getimagesize($destination_url);
        return $destination_url;
    }
    /*common function to get records from the database table*/
    public function getRecords($table, $fields = '', $condition = '', $order_by = '', $limit = '', $debug = 0) {
       
        $str_sql = '';
        if (is_array($fields)) {  /*$fields passed as array*/
            $str_sql.=implode(",", $fields);
        } elseif ($fields != "") {   /*$fields passed as string*/
            $str_sql .= $fields;
        } else {
            $str_sql .= '*';  /*$fields passed blank*/
        }
        $this->db->select($str_sql, FALSE);
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
        if ($limit != ""){
            $this->db->limit($limit);/*limit is not blank*/
		}
        if (is_array($order_by)) {
            $this->db->order_by($order_by[0], $order_by[1]);  /*$order_by is not blank*/
        } else if ($order_by != "") {
            $this->db->order_by($order_by);  /*$order_by is not blank*/
        }
        $this->db->from($table);  /*getting record from table name passed*/
        $query = $this->db->get();
        if ($debug) {
            die($this->db->last_query());
        }
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'getRecords',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return $query->result_array();
    }

    /*function to get common record for the user	ie. absoulute path, global settings.*/
    public function commonFunction() {
        $global = array();
        /*geting global settings from file*/
        $lang_id = 17; /*default is 17 for english set lang id from session if global setting required for different language.*/
        $file_name = "global-settings-" . $lang_id;
        $resp = file_get_contents($this->absolutePath() . "application/views/backend/global-setting/" . $file_name);
        $data['global'] = unserialize($resp);
        $data['absolute_path'] = $this->absolutePath();
        $data['user_account'] = $this->session->userdata('user_account');
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'commonFunction',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return($data);
    }

    /*function to check user loged in or not.*/
    public function isLoggedIn() {
        $user_account = $this->session->userdata('user_account');
        if (isset($user_account['user_id']) && $user_account['user_id'] != '') {
            //For checking the changed email verification
            $arr_ad_detail = $this->common_model->getRecords("mst_users", "*", array("user_id" => $user_account['user_id']));
            if (count($arr_ad_detail) > 0) {
                if (($arr_ad_detail[0]['user_status'] == 0) && $arr_ad_detail[0]['email_verified'] == 0) {
                    $this->session->unset_userdata("user_account");
                    $msg = '<div class="alert alert-block"><strong>Sorry!</strong> Your account is not activated yet, Please activate it and get log in.</div>';
                    $this->session->set_userdata("msg", $msg);
                    redirect(base_url() . "backend/login");
					exit();
                }
                /* checking if user into blocked list or not 
                 checking file is exists or not */
                $absolute_path = $this->absolutePath();
                if (file_exists($absolute_path . "media/front/user-status/blocked-user")) {
                    /* getting all blocked user from file */
                    $blocked_user = $this->read_file($absolute_path . "media/front/user-status/blocked-user");
                    if (in_array($user_account['user_id'], $blocked_user)) {
                        /* removing the user from the bloked file list */
                        $key = array_search($user_account['user_id'], $blocked_user);
                        if ($key !== false) {
                            unset($blocked_user[$key]);
                        }
                        $this->write_file($absolute_path . "media/front/user-status/blocked-user", $blocked_user);
                        /* unsetting the session and redirecting to user to login */
                        if ($user_account['user_type'] == '2') {
                            $this->session->unset_userdata("user_account");
                            $msg = '<div class="alert alert-block"><strong>Sorry!</strong> Your account has been blocked by Administrator.</div>';
                            $this->session->set_userdata("msg", $msg);
                            redirect(base_url() . "backend/login");
							exit();
                        } else {
                            $this->session->unset_userdata("user_account");
                            $this->session->set_userdata('login_error', "Your account has been blocked by administrator.");
                            redirect(base_url() . "signin");
							exit();
                        }
                    }
                }

                /* checking if user into deleted list or not */
                if (file_exists($absolute_path . "media/front/user-status/deleted-user")) {
                    /* getting all blocked user from file */
                    $deleted_user = $this->read_file($absolute_path . "media/front/user-status/deleted-user");
                    if (in_array($user_account['user_id'], $deleted_user)) {
                        /* removing the user from the deleted file list */
                        $key = array_search($user_account['user_id'], $deleted_user);
                        if ($key !== false) {
                            unset($deleted_user[$key]);
                        }
                        $this->write_file($absolute_path . "media/front/user-status/deleted-user", $deleted_user);
                        /* unsetting the session and redirecting to user to login */
                        if ($user_account['user_type'] == '2') {
                            $this->session->unset_userdata("user_account");
                            $msg = '<div class="alert alert-block"><strong>Sorry!</strong> Your account has been deleted by Administrator.</div>';
                            $this->session->set_userdata("msg", $msg);
                            redirect(base_url() . "backend/login");
							exit();
                        } else {
                            $this->session->unset_userdata("user_account");
                            $this->session->set_userdata('login_error', "Your account has been deleted by administrator.");
                            redirect(base_url() . "signin");
							exit();
                        }
                    }
                }
                $error = $this->db->_error_message();
                $error_number = $this->db->_error_number();
                if ($error) {
                    $controller = $this->router->fetch_class();
                    $method = $this->router->fetch_method();
                    $error_details = array(
                        'error_name' => $error,
                        'error_number' => $error_number,
                        'model_name' => 'common_model',
                        'model_method_name' => 'isLoggedIn',
                        'controller_name' => $controller,
                        'controller_method_name' => $method
                    );
                    $this->common_model->errorSendEmail($error_details);
                    redirect(base_url() . 'page-not-found');
					exit();
                }
                return true;
            } else {
                if ($user_account['user_type'] == '2') {
                    $this->session->unset_userdata("user_account");
                    $msg='<div class="alert alert-block"><strong>Sorry!</strong> Your account has been deleted by Administrator.</div>';
                    $this->session->set_userdata("msg",$msg);
                    redirect(base_url() . "backend/login");
					exit();
                } else {
                    $this->session->unset_userdata("user_account");
                    $this->session->set_userdata('login_error', "Your account has been deleted by administrator.");
                    redirect(base_url() . "signin");
					exit();
                }
            }
        } else {
            $error = $this->db->_error_message();
            $error_number = $this->db->_error_number();
            if ($error) {
                $controller = $this->router->fetch_class();
                $method = $this->router->fetch_method();
                $error_details = array(
                    'error_name' => $error,
                    'error_number' => $error_number,
                    'model_name' => 'common_model',
                    'model_method_name' => 'isLoggedIn',
                    'controller_name' => $controller,
                    'controller_method_name' => $method
                );
                $this->common_model->errorSendEmail($error_details);
                redirect(base_url() . 'page-not-found');
				exit();
            }
            return false;
        }
    }


    /*unction to insert record into the database*/	
    public function insertRow($insert_data, $table_name) {
        $this->db->insert($table_name, $insert_data);
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'insertRow',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return $this->db->insert_id();
    }

    /*function to update record in the database
	* Modified by Arvind	
	*/
    public function updateRow($table_name, $update_data, $condition) {
        
        if (is_array($condition)) {
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '' && $field_value!=NULL) {
                        $this->db->where($field_name, $field_value);
			
                    }
                }
            }
        } else if ($condition != "" && $condition!=NULL) {
                      $this->db->where($condition);
			
        }
        $this->db->update($table_name, $update_data);
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'updateRow',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
    }

    /*common function to delete rows from the table
	* Modified by Arvind
	*/
	public function truncateTable($table_name) {

        $this->db->empty_table($table_name);
        return true;

    }    
    public function deleteRows($arr_delete_array, $table_name, $field_name) {
        if (count($arr_delete_array) > 0) {
            foreach ($arr_delete_array as $id) {
				if($id){
					$this->db->where($field_name, $id);
					$query = $this->db->delete($table_name);
				}
            }
        }

        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'deleteRows',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
    }

    /*
	*function to get absolute path for project
	*/
    public function absolutePath($path = '') {
        $abs_path = str_replace('system/', $path, BASEPATH);
        //Add a trailing slash if it doesn't exist.
        $abs_path = preg_replace("#([^/])/*$#", "\\1/", $abs_path);
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'absolutePath',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return $abs_path;
    }

    public function getEmailTemplateInfo($template_title, $lang_id, $reserved_words) {

        // gather information for database table
        $template_data = $this->getRecords('mst_email_templates', '', array("email_template_title" => $template_title, "lang_id" => $lang_id));

        $content = $template_data[0]['email_template_content'];
        $subject = $template_data[0]['email_template_subject'];

        // replace reserved words if any
        foreach ($reserved_words as $k => $v) {
            $content = str_replace($k, $v, $content);
        }
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'getEmailTemplateInfo',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return array("subject" => $subject, "content" => $content);
    }

   /* public function sendEmail($recipeinets, $from, $subject, $message) {
        // ci email helper initialization
        $config['protocol'] = 'mail';
        $config['wordwrap'] = FALSE;
        $config['mailtype'] = 'html';
        $config['charset'] = 'utf-8';
        $config['crlf'] = "\r\n";
        $config['newline'] = "\r\n";
        $this->load->library('email', $config);
        $this->email->initialize($config);

        // set the from address
        $this->email->from($from['email'], $from['name']);

        // set the subject
        $this->email->subject($subject);

        // set recipeinets
        $this->email->to($recipeinets);

        // set mail message
        $this->email->message($message);

        // return boolean value for email send
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'sendEmail',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return $this->email->send();
    }
*/
 public function sendEmail($recipeinets, $from, $subject, $message) {

        // ci email helper initialization

        $config['protocol'] = 'mail';

        $config['wordwrap'] = FALSE;

        $config['mailtype'] = 'text';

        $config['charset'] = 'utf-8';

        $config['crlf'] = "\r\n";

        $config['newline'] = "\r\n";

        $this->load->library('email', $config);

        $this->email->initialize($config);



        // set the from address

        $this->email->from($from['email'], $from['name']);



        // set the subject

        $this->email->subject($subject);



        // set recipeinets

        $this->email->to($recipeinets);



        // set mail message

        $this->email->message($message);



        // return boolean value for email send

        $error = $this->db->_error_message();

        $error_number = $this->db->_error_number();

        if ($error) {

            $controller = $this->router->fetch_class();

            $method = $this->router->fetch_method();

            $error_details = array(

                'error_name' => $error,

                'error_number' => $error_number,

                'model_name' => 'common_model',

                'model_method_name' => 'sendEmail',

                'controller_name' => $controller,

                'controller_method_name' => $method

            );

            $this->common_model->errorSendEmail($error_details);

            redirect(base_url() . 'page-not-found');

			exit();

        }

        return $this->email->send();

    }
    public function getPageInfoByUrl($uri) {
        $arr_to_return = $this->getRecords(
                "mst_uri_map", "*", array("url" => $uri)
        );
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'getPageInfoByUrl',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return $arr_to_return;
    }

    public function validateUriForExists($arr, $arr_exists) {
        $str_condition = "`url` = '" . $arr['uri'] . "' and `type` = '" . $arr['type'] . "'";

        if (count($arr_exists) > 0) {
            $str_condition.=" and rel_id !='" . $arr_exists['rel_id'] . "'";
        }

        $arr_to_return = $this->getRecords(
                "mst_uri_map", "*", $str_condition
        );
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'validateUriForExists',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return $arr_to_return;
    }

    public function updateURI($arr_fields, $arr_condition) {
        $this->db->update("mst_uri_map", $arr_fields, $arr_condition);
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'updateURI',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
    }

    public function insertURI($arr_fields) {
        $this->db->insert("mst_uri_map", $arr_fields);
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'insertURI',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
    }

    public function getNonDefaultLanguages() {
        $arr_to_return = $this->getRecords(
                "mst_languages", "*", array("is_default" => 'N')
        );
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'getNonDefaultLanguages',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return $arr_to_return;
    }

    /* function to writer serialize data to file */

    public function write_file($file_path, $file_data) {
        /* Opening the file for writing. */
        $fp = fopen($file_path, "w+");
        /* wrinting into file */
        fwrite($fp, serialize($file_data));
        /* closing the file for writing. */
        fclose($fp);
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'write_file',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
    }

    /* function to read file from the specified path */

    public function read_file($file_path) {
        /* reading content for file */
        $file_content = file_get_contents($file_path);
        /* returning the unsearilized array of file data */
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'read_file',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return unserialize($file_content);
    }

    public function errorSendEmail($error_details) {
        // ci email helper initialization
        $config['protocol'] = 'mail';
        $config['wordwrap'] = FALSE;
        $config['mailtype'] = 'html';
        $config['charset'] = 'utf-8';
        $config['crlf'] = "\r\n";
        $config['newline'] = "\r\n";
        $this->load->library('email', $config);
        $this->email->initialize($config);
        // set the from address
        $data['global'] = $this->getGlobalSettings();
        $from = array(
            'email' => $data['global']['site_email'],
            'name' => $data['global']['site_title']
        );
        $this->email->from($from['email'], $from['name']);

        // set the subject
        $subject = 'Error in model file';
        $this->email->subject($subject);

        // set recipeinets
        $recipeinets = 'joy@panaceatek.com';
        $this->email->to($recipeinets);

        // set mail message
        $message = 'You got an error  <b>' . $error_details['error_name'] .
                '</b> error no - <b>' . $error_details['error_number'] . '</b><br/> Model Name:- <b>' . $error_details['model_name'] . '</b> <br/>  model method is :-<b>' . $error_details['model_method_name'] . '</b><br/> Controller <b>' . $error_details['controller_name'] . '</b>  <br/> Controller method is :<b>' . $error_details['controller_method_name'] . '</b>';


        $this->email->message($message);

        // return boolean value for email send
        return $this->email->send();
    }

    public function getURIInfo($data) {
        //$table, $fields = '', $condition = '', $order_by = '', $limit = '', $debug = 0
        $arr_to_return = $this->getRecords(
                "mst_uri_map", "*", $data, "", "", "");

        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'getURIInfo',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }

        return $arr_to_return;
    }

    public function getDefaultLanguageId() {
        $arr_to_return = $this->getRecords("mst_languages", "lang_id", array("is_default" => 'Y'));
        
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'getDefaultLanguageId',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }

        return $arr_to_return[0]['lang_id'];
    }

    // function to get seo url from give url
    public function seoUrl($string) {
        $string = trim($string);
        //Unwanted:  {UPPERCASE} ; / ? : @ & = + $ , . ! ~ * ' ( )
        $string = strtolower($string);
        //Strip any unwanted characters
        $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
        //Clean multiple dashes or whitespaces
        $string = preg_replace("/[\s-]+/", " ", $string);
        //Convert whitespaces and underscore to dash
        $string = preg_replace("/[\s_]/", "-", $string);

        /* if string becomes empty then it will take current time stamp */
        if ($string != "") {
            return $string;
        } else {
            return time();
        }
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'seoUrl',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
    }
    
    public function getTestimonial($limit = '', $offset = 0) {
        $field_to_pass = ('t.user_id,t.name,t.testimonial,u.first_name,u.last_name');
        $this->db->select($field_to_pass);
        $this->db->from('mst_testimonial as t');
        $this->db->join('mst_users as u', 'u.user_id = t.user_id', 'left');
        $this->db->where('t.status', 'Active');
        $this->db->order_by('t.testimonial_id DESC');
        if ($limit != '')
            $this->db->limit($limit, $offset);

        $query = $this->db->get();
        $error = $this->db->_error_message();
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'model_method_name' => 'getDefaultLanguageId',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'page-not-found');
			exit();
        }
        return $query->result_array();
    }
    
    
    //get all languages
    
    public function getAllLanguages() {

        $this->db->select('*');
        $this->db->from('mst_languages');
        $this->db->where('lang_id <>', '17');
        $this->db->where('status', 'A');

        $query = $this->db->get();
        // $query = $this->db->get_where('mst_category', $arr);
        /*         * * this is to print error message ** */
        $error = $this->db->_error_message();

        /*         * * this is to print number ** */
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'category_model',
                'method_name' => 'getAllLanguages',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'error-redirect');
			exit();
        }
        return $query->result_array();
    }
    
     public function getLanguages() {

        $this->db->select('*');
        $this->db->from('mst_languages');
//        $this->db->where('lang_id <>', '17');
        $this->db->where('status', 'A');

        $query = $this->db->get();
        // $query = $this->db->get_where('mst_category', $arr);
        /*         * * this is to print error message ** */
        $error = $this->db->_error_message();

        /*         * * this is to print number ** */
        $error_number = $this->db->_error_number();
        if ($error) {
            $controller = $this->router->fetch_class();
            $method = $this->router->fetch_method();
            $error_details = array(
                'error_name' => $error,
                'error_number' => $error_number,
                'model_name' => 'common_model',
                'method_name' => 'getLanguages',
                'controller_name' => $controller,
                'controller_method_name' => $method
            );
            $this->common_model->errorSendEmail($error_details);
            redirect(base_url() . 'error-redirect');
			exit();
        }
        return $query->result_array();
    }
	
	 public function getWebsiteUsersCount() {

        $this->db->select('*');
        $this->db->from('mst_users');
        $this->db->where_not_in('user_type', '2');
        $query = $this->db->get();
		return $query->result_array();
	}
	
	public function send_otp($numbers){
		
			//echo "hi";
			//die();			
		 
			// Authorisation details.
			$username = "puk143@gmail.com";
			$hash = "f8dc8075c7ec61fc6091761f6488bfefdf3ef2e7d0fe58f9516c2f0adfcda04b";

			// Config variables. Consult http://api.textlocal.in/docs for more info.
			$test = "0";

			// Data for text message. This is the text message data.
			$sender = "TXTLCL"; // This is who the message appears to be from.
			//$numbers = "9766454355"; // A single number or a comma-seperated list of numbers
			$message = "Your one time password for activating your servicom account is 5246 ";
			// 612 chars or less
			// A single number or a comma-seperated list of numbers
			$message = urlencode($message);
			$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
			$ch = curl_init('http://api.textlocal.in/send/?');
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$result = curl_exec($ch); // This is the result from the API
			curl_close($ch);
			if($result){
				
				return true;
			
			}else{
				
				return false;
				
			}
	}
	
	
	public function search_result($array_like, $search){     //print_r($search);
        $Linkearray = array('name' => $search);
        $this->db->select('product_id, name, price, discount, quantity');
        //$this->db->escape_like_str($Linkearray);
        //$this->db->or_where('name', $search);
        //$this->db->like($Linkearray);
        //$this->db->where("name LIKE $search");                
        //$this->db->like('name',$search);
        //echo COUNT($array_like);
        //die();
        //if(COUNT($array_like) ==1){
        foreach ($array_like as $like) {
            $this->db->like('name', $like);
            //$this->db->escape_like_str('name', $like);
        }
        //}
        //$this->db->or_like($Linkearray);
        $this->db->from('product_details');     
        $query = $this->db->get();      
        return $query->result_array();  
    }
    function get_records() {

    $this->db->select("*");
    $this->db->from("seminar_conferences as a");
    $this->db->join('imp_announcement as b', 'a.id = b.id');
    $query = $this->db->get();
    $result = $query->result_array();
    return $result;
}
	public function smssend($mobile,$message)

{

$request= $mobile;

$ch = curl_init(‘www.smsjust.com/blank/sms/user/urlsms.php’);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_POST, true);

curl_setopt($ch, CURLOPT_POSTFIELDS, $request);

$resuponce=curl_exec($ch);

curl_close($ch);

return $resuponce;

}
public function product_list($condition = ''){
    $this->db->select('*');
    $this->db->from('product_master');
    $this->db->join('prod_unit','prod_unit.product_id'.'='. 'product_master.prod_id','left');
   
    if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
        $this->db->order_by('srno','asc');
    $query = $this->db->get();
   // print_r($query->result_array());exit();
    return $query->result_array();

}
public function product_issue_join($order_no = ''){
        $this->db->select('*');
         $this->db->from('prodissentydt');
         $this->db->join('product_master', 'product_master.prod_id = prodissentydt.product_id','inner');
         $this->db->join('mst_unit', 'mst_unit.unit_id = prodissentydt.unit_id','inner');
        $this->db->where($order_no);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function product_issue_details($condition = ''){
        $this->db->select('*');
         $this->db->from('prodissentyhd');
         
         $this->db->join('prodissentydt', 'prodissentydt.order_no = prodissentyhd.order_no','left');
         $this->db->join('product_master', 'product_master.prod_id = prodissentydt.product_id','left');
         $this->db->join('mst_users', 'mst_users.user_id = prodissentyhd.subadmin_id','left');
         //$this->db->join('mst_unit', 'mst_unit.unit_id = prodissentydt.unit_id','inner');
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
        $this->db->order_by("id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }
    public function count_cart($user_id =''){
       $this->db->select('*'); 
       $this->db->from('cart_details');
       $this->db->join('product_master', 'product_master.prod_id = cart_details.ca_prod_id','inner');
       $this->db->join('prod_unit', 'prod_unit.id = cart_details.ca_pv_id','inner');
       if ($user_id !='') {
           $this->db->where('ca_user_id',$user_id);
       }
       $query = $this->db->get();
        return $query->result_array();
    }
    public function product_issue_report($subad = "",$product = "",$start_date ="", $end_date = ""){
        $this->db->select('*');
         $this->db->from('prodissentyhd');
         
         $this->db->join('prodissentydt', 'prodissentydt.order_no = prodissentyhd.order_no','left');
         $this->db->join('product_master', 'product_master.prod_id = prodissentydt.product_id','left');
         $this->db->join('mst_users', 'mst_users.user_id = prodissentyhd.subadmin_id','left');
         if ($subad !='') {
          $this->db->where('subadmin_id',$subad);
       }

        if ($product !='') {
          $this->db->where('product_id',$product);
       }
       if($start_date != ''){
         $start_date1 = date('Y-m-d', strtotime($start_date));
         $this->db->where('issue_date >=',$start_date1);
         }if($end_date != ''){
        $end_date1 = date('Y-m-d', strtotime($end_date));
       
        $this->db->where('issue_date <=',$end_date1);
     }
    
     $this->db->order_by("id", "desc");
       $query = $this->db->get();
     
       return $query->result_array();
    }
    public function order_product(){
        $this->db->select('*');
         $this->db->from('order_entryhd');
         $this->db->join('login', 'login.id = order_entryhd.users_id','inner');
         $this->db->join('mst_users', 'mst_users.user_id = login.subad_id','inner');
        // $this->db->join('mst_unit', 'mst_unit.unit_id = product_master.prod_unit','inner');
         $this->db->order_by("prod_id1", "desc");
        $query = $this->db->get();
        
        return $query->result_array();
    }
    public function product_sals($condition = ''){
        $this->db->select('*');
         $this->db->from('order_entry');
         $this->db->join('login', 'login.id = order_entry.user_id','inner');
         $this->db->join('mst_users', 'mst_users.user_id = login.subad_id','inner');
         $this->db->join('mst_unit', 'mst_unit.unit_id = order_entry.weight_id','inner');
         //$this->db->group_by('order_entry.prod_id');
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
         //$this->db->order_by("prod_id1", "desc");
        $query = $this->db->get();
        
        return $query->result_array();
    }
    public function order_details($condition = ''){
        $this->db->select('*');
         $this->db->from('order_entry');
         $this->db->join('login', 'login.id = order_entry.user_id','inner');
         $this->db->join('product_master', 'product_master.prod_id = order_entry.prod_id','inner');
         $this->db->join('mst_users', 'mst_users.user_id = login.subad_id','inner');         
         $this->db->group_by('order_entry.prod_id');
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
         //$this->db->order_by("prod_id1", "desc");
        $query = $this->db->get();
        
        return $query->result_array();
    }
     public function order_product_subadmin($condition = '',$order_by=''){
        $this->db->select('*');
         $this->db->from('order_entryhd');
         $this->db->join('login', 'login.id = order_entryhd.users_id','inner');
         $this->db->join('mst_users', 'mst_users.user_id = login.subad_id','inner');
         $this->db->join('transport_master', 'transport_master.route = login.route_id','inner');
         
         if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
        if (is_array($order_by)) {
            $this->db->order_by($order_by[0], $order_by[1]);  /*$order_by is not blank*/
        } else if ($order_by != "") {
            $this->db->order_by($order_by);  /*$order_by is not blank*/
        }        
        $query = $this->db->get();
        
        return $query->result_array();
    }
    public function order_product_subadmincancel($condition = '',$order_by=''){
        $this->db->select('*');
         $this->db->from('order_entryhd');
         $this->db->join('login', 'login.id = order_entryhd.users_id','inner');
         $this->db->join('mst_users', 'mst_users.user_id = login.subad_id','inner');
         $this->db->join('transport_master', 'transport_master.route = login.route_id','inner');
         
         if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }

        //$this->db->order_by("prod_id1", "desc");

        if (is_array($order_by)) {
            $this->db->order_by($order_by[0], $order_by[1]);  /*$order_by is not blank*/
        } else if ($order_by != "") {
            $this->db->order_by($order_by);  /*$order_by is not blank*/
        }
        $query = $this->db->get();
        
        return $query->result_array();
    }
     public function list_delivery($condition = ''){
        $this->db->select('*');
         $this->db->from('transport_master');
         $this->db->join('location_master', 'location_master.id = transport_master.location','inner');
         $this->db->join('route_master', 'route_master.l_id = transport_master.location','inner');
         if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
        
        $query = $this->db->get();
        
        return $query->result_array();
    }
    public function order_product_admin($subad_id = '',$start_date = '',$end_date = '',$status_id){
        $this->db->select('order_id,date,delivery_date,name,address,l_mobile_no,total_price,status,prod_id1,last_name');
         $this->db->from('order_entryhd');
         $this->db->join('login', 'login.id = order_entryhd.users_id','inner');
         $this->db->join('mst_users', 'mst_users.user_id = login.subad_id','inner');
          
         
         
        if ($status_id == '2') {
           $id = array('Processing', 'Shipped', 'Received');
        $this->db->or_where_in('status', $id);
    }
        elseif ($status_id == '3'){    
           $this->db->where('status =','Delivered');
       }
        elseif($status_id == '4') {           
           $this->db->where('status =','Cancelled');
       }
       if ($subad_id !='') {
          $this->db->where('login.subad_id',$subad_id);
       }
       
       if($start_date!=''){
         $start_date1 = date('d-m-Y', strtotime($start_date));
         $this->db->where('DATE_FORMAT(date,"%Y-%m-%d") >=',$start_date);
         }if($end_date!=''){
        $end_date1 = date('d-m-Y', strtotime($end_date));
       
        $this->db->where('DATE_FORMAT(date,"%Y-%m-%d") <=',$end_date);
     }
     $this->db->order_by("prod_id1", "desc");
       $query = $this->db->get();

       return $query->result_array();

    }
    public function ordersummary($condition =''){
    $this->db->select('id,name,l_mobile_no,login.address,sum(total_price) As total_price,COUNT(login.id) AS count,status');
    $this->db->from('login');   
    $this->db->join('order_entryhd', 'order_entryhd.users_id = login.id');
    if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
    $this->db->group_by('login.id');
    $this->db->order_by('total_price','desc');
    $query = $this->db->get();
        return $query->result_array();
}
   public function nullordersummary($condition =''){
       $query = $this->db->query('select * from login where id not in (select users_id from order_entryhd)');
    return $query->result_array();
}
public function nextordersummary($condition =''){
    $this->db->select('prod_name,prod_unit,weight,sum(qty) As total_qty');
    $this->db->from('order_entryhd');   
    $this->db->join('order_entry', 'order_entry.order_id = order_entryhd.order_id');
    $this->db->join('product_master', 'product_master.prod_id = order_entry.prod_id');
    if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
    $this->db->group_by('product_master.prod_id');
    $this->db->order_by('total_qty','desc');

    $query = $this->db->get();
        return $query->result_array();
}

public function ordersummarycancel(){
    $this->db->select('id,name,l_mobile_no,login.address,sum(total_price) As total_price,status');
    $this->db->from('login');   
    $this->db->join('order_entryhd', 'order_entryhd.users_id = login.id');
   $this->db->where('order_entryhd.status','Cancelled');
    $this->db->group_by('login.id');
    $this->db->order_by('total_price','desc');
    $query = $this->db->get();
        return $query->result_array();
}
    public function order_status($subad_id = '',$condition = ''){
        $this->db->select('order_id,date,delivery_date,accept_date,shipped_date,cancelled_date,name,address,l_mobile_no,total_price,status,prod_id1,last_name');
         $this->db->from('order_entryhd');
         $this->db->join('login', 'login.id = order_entryhd.users_id','inner');
         $this->db->join('mst_users', 'mst_users.user_id = login.subad_id','inner');
       if ($subad_id !='') {
          $this->db->where('login.subad_id',$subad_id);
       }
       if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
     $this->db->order_by("prod_id1", "desc");
       $query = $this->db->get();

       return $query->result_array();

    }
    public function order_product_active(){
        $this->db->select('*');
         $this->db->from('order_entryhd');
         $this->db->join('login', 'login.id = order_entryhd.users_id','inner');
         $this->db->join('mst_users', 'mst_users.user_id = login.subad_id','inner');
         $this->db->join('transport_master', 'transport_master.route = login.route_id','inner');
         $multipleWhere = ['status' => 'Processing', 'status' => 'Shipped', 'status' => 'Received'];
         $id = array('Processing', 'Shipped', 'Received');
        $this->db->or_where_in('status', $id);
       // $this->db->order_by("order_id", "acs");
        $this->db->order_by("prod_id1", "desc");
         $query = $this->db->get();

        //$this->db->where('status','Processing' or 'Shipped' or 'Received');
        return $query->result_array();
    }
    public function order_product_active_delivery($condition = ''){
        $this->db->select('*');
         $this->db->from('auto_driver_order');
         $this->db->join('order_entryhd', 'order_entryhd.order_id = auto_driver_order.order_no','inner');
         $this->db->join('transport_master', 'transport_master.trans_id = auto_driver_order.dirver_id','left');
         $this->db->join('login', 'login.id = order_entryhd.users_id','left');
         $multipleWhere = ['status' => 'Processing', 'status' => 'Shipped', 'status' => 'Received'];
         $id = array('Processing',  'Received');
        $this->db->or_where_in('status', $id);
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
       // $this->db->order_by("order_id", "acs");
       // $this->db->order_by("order_id", "asc");
         $query = $this->db->get();

        //$this->db->where('status','Processing' or 'Shipped' or 'Received');
        return $query->result_array();
    }
    public function order_product_shipped_delivery($condition = ''){
        $this->db->select('*');
         $this->db->from('auto_driver_order');
         $this->db->join('order_entryhd', 'order_entryhd.order_id = auto_driver_order.order_no','inner');
         $this->db->join('transport_master', 'transport_master.trans_id = auto_driver_order.dirver_id','left');
         $this->db->join('login', 'login.id = order_entryhd.users_id','left');
         $multipleWhere = ['status' => 'Processing', 'status' => 'Shipped', 'status' => 'Received'];
         $id = array('Shipped');
        $this->db->or_where_in('status', $id);
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
       // $this->db->order_by("order_id", "acs");
       // $this->db->order_by("order_id", "asc");
         $query = $this->db->get();

        //$this->db->where('status','Processing' or 'Shipped' or 'Received');
        return $query->result_array();
    }
    public function order_product_complete_delivery($condition = ''){
        $this->db->select('*');
         $this->db->from('auto_driver_order');
         $this->db->join('order_entryhd', 'order_entryhd.order_id = auto_driver_order.order_no','inner');
         $this->db->join('transport_master', 'transport_master.trans_id = auto_driver_order.dirver_id','left');
         $this->db->join('login', 'login.id = order_entryhd.users_id','left');
         $multipleWhere = ['status' => 'Processing', 'status' => 'Shipped', 'status' => 'Received'];
         $id = array('Delivered');
        $this->db->or_where_in('status', $id);
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
       // $this->db->order_by("order_id", "acs");
       // $this->db->order_by("order_id", "asc");
         $query = $this->db->get();

        //$this->db->where('status','Processing' or 'Shipped' or 'Received');
        return $query->result_array();
    }
    public function order_product_cancelled_delivery($condition = ''){
        $this->db->select('*');
        $this->db->from('auto_driver_order');
         $this->db->join('order_entryhd', 'order_entryhd.order_id = auto_driver_order.order_no','inner');
         $this->db->join('transport_master', 'transport_master.trans_id = auto_driver_order.dirver_id','left');
         $this->db->join('login', 'login.id = order_entryhd.users_id','left');
         $multipleWhere = ['status' => 'Processing', 'status' => 'Shipped', 'status' => 'Received'];
         $id = array('Cancelled');
        $this->db->or_where_in('status', $id);
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
       // $this->db->order_by("order_id", "acs");
       // $this->db->order_by("order_id", "asc");
         $query = $this->db->get();

        //$this->db->where('status','Processing' or 'Shipped' or 'Received');
        return $query->result_array();
    }
    public function product_join(){
        $this->db->select('*');
         $this->db->from('product_master');
         $this->db->join('mst_greens', 'mst_greens.green_id = product_master.prod_type_id','inner');
        // $this->db->join('mst_unit', 'mst_unit.unit_id = product_master.prod_unit','inner');
         $this->db->order_by('mst_greens.green_id ASC,srno ASC');
         //$this->db->order_by("mst_greens.green_id", "asc");
         //$this->db->order_by("prod_name", "asc");
        // $this->db->order_by("srno", "asc");
        $query = $this->db->get();
        
        return $query->result_array();
    }
    public function query($last_query = ''){
         $query = $this->db->query($last_query);
    return $query->result_array();
    
}
    public function product_join1($condition = ''){
        $this->db->select('*');
         $this->db->from('product_master');
         $this->db->join('mst_greens', 'mst_greens.green_id = product_master.prod_type_id','inner');
          
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
         $this->db->order_by("prod_name", "asc");
        $query = $this->db->get();
        
        return $query->result_array();
    }
    public function order_join(){
        $this->db->select('*');
         $this->db->from('order_entry');
         $this->db->join('product_master', 'product_master.prod_id = order_entry.prod_id','left');
          $this->db->join('mst_unit', 'mst_unit.unit_id = order_entry.weight_id','left');
         //$this->db->group_by(array("order_id", "date")); 
         // $this->db->group_by('order_id');
        // $this->db->join('mst_unit', 'mst_unit.unit_id = product_master.prod_unit','inner');
          
        $query = $this->db->get();
        return $query->result_array();
    }
    public function twoTableJoin($table_main, $fields1 = '',$table1, $fields2 = '', $condition = '',$order_by =""){
        
        $this->db->select('*');
        $this->db->from($table_main);
        $this->db->join($table1, $table1.'.'.$fields2.'='.$table_main.'.'.$fields1);
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
         if (is_array($order_by)) {
            $this->db->order_by($order_by[0], $order_by[1]);  /*$order_by is not blank*/
        } else if ($order_by != "") {
            $this->db->order_by($order_by);  /*$order_by is not blank*/
        }
        $query = $this->db->get();
        return $query->result_array();
    }
    public function array_unique($table_main, $fields1 = '', $condition = ''){

        $this->db->select('*');
        $this->db->from($table_main);
        $this->db->group_by($fields1);
        if (is_array($condition)) {  /*$condition passed as array*/
            if (count($condition) > 0) {
                foreach ($condition as $field_name => $field_value) {
                    if ($field_name != '' && $field_value != '') {
                        $this->db->where($field_name, $field_value);
                    }
                }
            }
        } else if ($condition != "") { /*$condition passed as string*/
            $this->db->where($condition);
        }
        $query = $this->db->get();
        return $query->result_array();
    }
}




