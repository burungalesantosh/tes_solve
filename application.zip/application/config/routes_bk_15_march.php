<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/



/* admin login, dashboard and forgot password */
$route['admin'] = "admin/index";
$route['default_controller'] = "front/index";

$route['backend/change-languageversion-for-functionality'] = "admin/change_language_for_functionality";


$route['backend'] = "admin/index";
$route['backend/login'] = "admin/index";
$route['backend/index'] = "admin/index";
$route['backend/home'] = "admin/home";
$route['backend/dashboard'] = "admin/home";
$route['backend/log-out'] = "admin/logout";
$route['backend/forgot-password'] = "admin/forgotPassword";
$route['backend/forgot-password-email'] = "admin/checkForgotPasswordEmail";
/* admin login, dashboard and forgot password end here */



/* Manage Role: */
$route['backend/role/list']="role/listRole";
$route['backend/role/edit/(:any)']="role/addRole/$1";
$route['backend/role/add']="role/addRole";
$route['backend/role/check-role']="role/checkRole";
/* Manage Role End Here */

/* Manage Admin  */
$route['backend/admin/list']="admin/listAdmin";
$route['backend/admin/change-status']="admin/changeStatus";
$route['backend/admin/add']="admin/addAdmin";
$route['backend/admin/check-admin-username']="admin/checkAdminUsername";
$route['backend/admin/check-admin-email']="admin/checkAdminEmail";
$route['backend/admin/account-activate/(:any)']="admin/activateAccount/$1";
$route['backend/admin/edit/(:any)']="admin/editAdmin/$1";
$route['backend/admin/profile']="admin/adminProfile";
$route['backend/admin/edit-profile']="admin/editProfile";
$route['backend/country-change-language/(:any)'] = "countries/changeLanguage/$1";
$route['backend/country/country-name']="countries/getAllCountryNames";
/* Manage Admin End Here */

/*
 * Manage User Start Here
 */

$route['backend/user/change-status']="user/changeStatus";
$route['backend/user/add']="user/addUser";
$route['backend/user/check-user-username']="user/checkUserUsername";
$route['backend/user/check-user-email']="user/checkUserEmail";
$route['backend/user/account-activate/(:any)']="user/activateAccount/$1";

$route['backend/user/view/(:any)']="user/userProfile/$1";
$route['backend/user/delete-user/(:any)']="user/deleteUser/$1";
$route['backend/user/reverification-link/(:any)']="user/reverificationLink/$1/$2";
$route['backend/user/change-status-email']="user/changeStatusEmail";
/*
 * Manage User End Here
 */

/*
 * Manage Employees Start Here
 */
$route['backend/employees/list']="employees/listEmployees";
$route['backend/employees/edit/(:any)']="employees/editEmployees/$1";
$route['backend/employees/edit']="employees/editEmployees";



/*
 * Manage Employees End Here
 */

/*
 * Manage Volunteer Start Here
 */

//$route['backend/user/list']="user/listUser";


/*
 * Manage Volunteer End Here
 */

/*
 * Manage email template routes
 */
$route['backend/email-template/list']="email_template/index";
$route['backend/edit-email-template/(:any)']="email_template/editEmailTemplate/$1";

/*
 * Manage email template routes end
 */
/*
 * Manage notification-template routes
 */
$route['backend/notification-template/list']="notification_template/index";
$route['backend/notification-template/add']="notification_template/add";
$route['backend/edit-notification-template/(:any)']="notification_template/editNotificationTemplate/$1";
$route['backend/send-notification/(:any)']="notification/sendNotification/$1";
//admin panel routes by pawan

$route['backend/product/add']="product/addProduct";
$route['backend/product/list']="product/product_list";
$route['backend/product/update/(:any)']="product/product_edit/$1";
$route['backend/product/update']="product/product_edit";

$route['backend/user/list']="user/listUser";
$route['backend/user/edit/(:any)']="user/editUser/$1";
$route['backend/user/edit']="user/editUser";
$route['backend/user/forget/(:any)']="user/userForget/$1";
$route['backend/user/forget']="user/userForget";

$route['backend/product/bulkupload']="product/product_bulk_upload";
$route['backend/product/continew-product-upload']="product/continew_product_upload";

$route['backend/stock/index']="stock/index";
$route['backend/stock/list']="stock/stock_list";





//Web-service routes starts here
$route['ws-login'] = "web_services/userLogin";
$route['ws-change_password'] = "web_services/userChangePassword";
$route['ws-view-userprofile'] = "web_services/userDetails";
$route['ws-edit-userprofile'] = "web_services/editUserDetails";

$route['ws-get-product-list'] = "web_services/getProductList";
$route['ws-get-product-details'] = "web_services/getProductDetails";
$route['ws-product-search'] = "web_services/product_search";

$route['ws-get-price-list'] = "web_services/getProductList";
$route['ws-get-price-details'] = "web_services/getProductDetails";
$route['ws-price-search'] = "web_services/product_search";

$route['ws-get-stock-list'] = "web_services/getStockList";
$route['ws-get-stock-details'] = "web_services/getStockDetails";
$route['ws-stock-search'] = "web_services/stock_search";

// Km Agrawal Backend

$route['backend/listSeminarConferences'] = "SeminarConferences/listSeminarConferences";
$route['backend/editSeminarConferences'] = "SeminarConferences/editSeminarConferences";
$route['backend/editSeminarConferences/(:any)'] = "SeminarConferences/editSeminarConferences/$1";
$route['backend/addSeminarConferences'] = "SeminarConferences/addSeminarConferences";

$route['backend/listAnnouncement'] = "ImpAnnouncement/listAnnouncement";
$route['backend/editAnnouncement'] = "ImpAnnouncement/editAnnouncement";
$route['backend/editAnnouncement/(:any)'] = "ImpAnnouncement/editAnnouncement/$1";
$route['backend/addAnnouncement'] = "ImpAnnouncement/addAnnouncement";


$route['backend/listStudentTestimonial'] = "StudentTestimonial/listStudentTestimonial";
$route['backend/editStudentTestimonial'] = "StudentTestimonial/editStudentTestimonial";
$route['backend/editStudentTestimonial/(:any)'] = "StudentTestimonial/editStudentTestimonial/$1";
$route['backend/addStudentTestimonial'] = "StudentTestimonial/addStudentTestimonial";






//Front end Routes start hear

$route['about'] = "front/aboutus";
$route['governing-council'] = "front/governingCouncil";
$route['bsc-it'] = "front/BscIT";
$route['bsc-it/(:any)'] = "front/BscIT/$1";
$route['gallery'] = "front/Gallery";
$route['priti-yadav-sarode'] = "front/PritiYadavSarode";

$route['principle-msg'] = "front/PrincipleMsg";
$route['chairman-msg'] = "front/ChairmanMsg";
$route['aqar-report'] = "front/aqarReport";
$route['student-corner'] = "front/studentCorner";
$route['publication'] = "front/collegePublication";
$route['dept-details'] = "front/deptDetails";
$route['event-details'] = "front/eventDetails";
$route['event-details/(:any)'] = "front/eventDetails/$1";

$route['event-details-all'] = "front/eventDetailsAll";
$route['event-details-all/(:any)'] = "front/eventDetailsAll";

$route['imp-announcement-details'] = "front/impAnnouncementDetails";
$route['imp-announcement-details/(:any)'] = "front/impAnnouncementDetails/$1";

$route['imp-announcement-all'] = "front/impAnnouncementAll";
$route['imp-announcement-all/(:any)'] = "front/impAnnouncementAll";

//Done by Sagar dated 19022019//
$route['MCOM-Business-Management'] = "front/Mcom_BM";
$route['MCOM-Advance-Accountancy'] = "front/Mcom_AC";
$route['MA-History'] = "front/MA_Hist";
$route['MA-Economics'] = "front/MA_Eco";
$route['MSC-Chemistry'] = "front/Msc_chem";
$route['MSC-Physics'] = "front/Msc_phys";


$route['ravindra-rajwade'] = "front/ravindraRajwade";
$route['anagha-rane'] = "front/anaghaRane";
$route['pralhad-pawar'] = "front/pralhadPawar";

$route['ratna-nimbalkar'] = "front/ratnaNimbalkar";
$route['mahesh-bhiwandikar'] = "front/maheshBhiwandikar";
$route['kiran-chavan'] = "front/kiranChavan";
$route['bhanudas-mahajan'] = "front/bhanudasMahajan";

$route['amit-pandit'] = "front/amitpandit";
$route['rupesh-dubey'] = "front/rupeshDubey";
$route['vaishali-patil'] = "front/vaishaliPatil";
$route['anita-manna'] = "front/anitaManna";
$route['priti-sarode'] = "front/PritiYadavSarode";

$route['anagha-rane'] = "front/anaghaRane";
$route['arpita-kulkarni'] = "front/arpitaKulkarni";
$route['sambhaji-gujar'] = "front/sambhajiGujar";
$route['raghunath-kor'] = "front/raghunathKor";
$route['bhavana-patil'] = "front/bhavanaPatil";
$route['santosh-kulkarni'] = "front/santoshKulkarni";
$route['sujit-more'] = "front/sujitMore";
$route['suman-tripathi'] = "front/sumanTripathi";
$route['munish-pandey'] = "front/munishPandey";
$route['sanjay-patil'] = "front/sanjayPatil";

//End by Sagar dated 19022019//

$route['about-iqac'] = "front/aboutIQAC";
$route['vision-iqac'] = "front/vision_iqac";
$route['activities-iqac'] = "front/activities_iqac";
$route['members-iqac'] = "front/members_iqac";

// done by sunil 19-feb-2019

$route['bcom'] = "front/bCom";
$route['b-com-accounting'] = "front/bcomaccounting";
$route['b-com'] = "front/b_com";
$route['ba'] = "front/ba";
$route['bsc'] = "front/bsc";
$route['bsc-comp'] = "front/bsc_comp";
$route['bms'] = "front/bms";
$route['vision-iqac'] = "front/vision_iqac";
$route['activities-iqac'] = "front/activities_iqac";
$route['members-iqac'] = "front/members_iqac";


// done by sunil 22-feb-2019

$route['bsc_it'] = "front/bsc_it";
$route['physics'] = "front/physics";
$route['commerce'] = "front/commerce";
$route['economics'] = "front/economics";
$route['suresh-madhavi'] = "front/suresh_madhavi";
$route['sujata-tiwale'] = "front/sujata_tiwale";
$route['vilas-surwade'] = "front/vilas_surwade";
$route['manish_mishara'] = "front/manish_mishara";
$route['event-gallery'] = "front/eventGallary";


//done by sagar 25-02-2019

$route['rajbahadur-singh'] = "front/rajbahadursingh";
$route['ajay-pashankar'] = "front/ajay_pashankar";
$route['babita-doda'] = "front/babita_doda";
$route['renu-chaturvedi'] = "front/renu_chaturvedi";
$route['preeti-sarode'] = "front/preeti_sarode";
$route['vitthal-parab'] = "front/vitthal_parab";
$route['Meenal-Sohoni'] = "front/Meenal_Sohoni";
$route['vishwas-jadhav'] = "front/vishwas_jadhav";
$route['varsha-bobade'] = "front/varsha_bobade";
$route['jayshree-shukla'] = "front/jayshree_shukla";
$route['mahendra-dahiwale'] = "front/mahendra_dahiwale";
$route['mansi-barve'] = "front/mansi_barve";
$route['rekha-raghu'] = "front/rekha_raghu";
$route['rohidas-sanap'] = "front/rohidas_sanap";
$route['devanjali-dutta'] = "front/devanjali_dutta";
$route['khushboo-bhatia'] = "front/khushboo_bhatia";
$route['kiran-gomes'] = "front/kiran_gomes";
$route['mahendra-pandey'] = "front/mahendra_pandey";
$route['nishant-shirsath'] = "front/nishant_shirsath";
$route['sayli-gite'] = "front/sayli_gite";
$route['shraddha-ojha'] = "front/shraddha_ojha";
$route['chandan-devidasani'] = "front/chandan_devidasani";
$route['rubina-khan'] = "front/rubina_khan";
$route['sujeet-singh'] = "front/sujeet_singh";
$route['vastva-kumar'] = "front/vastva_kumar";
